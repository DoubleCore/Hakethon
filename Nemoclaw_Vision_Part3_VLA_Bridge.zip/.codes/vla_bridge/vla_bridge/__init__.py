"""VLA Bridge - gRPC bridge for robot control."""
