"""Shared transport utilities for chunked gRPC data transfer.

Based on LeRobot's transport/utils.py pattern.
"""

import io
import json
import logging
import pickle  # nosec B403
from typing import Any

logger = logging.getLogger(__name__)

CHUNK_SIZE = 2 * 1024 * 1024  # 2 MB
MAX_MESSAGE_SIZE = 4 * 1024 * 1024  # 4 MB


def send_bytes_in_chunks(
    data: bytes,
    message_class: Any,
    log_prefix: str = "",
) -> Any:
    """Generator that yields protobuf messages with chunked binary data.

    Mirrors LeRobot's chunked transfer protocol:
    TRANSFER_BEGIN -> TRANSFER_MIDDLE* -> TRANSFER_END
    """
    buffer = io.BytesIO(data)
    total_size = len(data)
    sent_bytes = 0

    logger.debug(f"{log_prefix} Sending {total_size / 1024 / 1024:.2f} MB")

    while sent_bytes < total_size:
        if sent_bytes == 0:
            state = 1  # TRANSFER_BEGIN
        elif sent_bytes + CHUNK_SIZE >= total_size:
            state = 3  # TRANSFER_END
        else:
            state = 2  # TRANSFER_MIDDLE

        chunk = buffer.read(min(CHUNK_SIZE, total_size - sent_bytes))
        yield message_class(transfer_state=state, data=chunk)
        sent_bytes += len(chunk)

    logger.debug(f"{log_prefix} Sent {sent_bytes} bytes complete")


def receive_bytes_in_chunks(iterator, log_prefix: str = "") -> bytes:
    """Receive chunked binary data from a gRPC stream iterator."""
    buffer = io.BytesIO()

    for item in iterator:
        state = item.transfer_state

        if state == 1:  # TRANSFER_BEGIN
            buffer.seek(0)
            buffer.truncate(0)
            buffer.write(item.data)
        elif state == 2:  # TRANSFER_MIDDLE
            buffer.write(item.data)
        elif state == 3:  # TRANSFER_END
            buffer.write(item.data)
            result = buffer.getvalue()
            logger.debug(f"{log_prefix} Received {len(result)} bytes")
            return result
        else:
            raise ValueError(f"Unknown transfer state: {state}")

    return buffer.getvalue()


def grpc_channel_options(
    max_receive_message_length: int = MAX_MESSAGE_SIZE,
    max_send_message_length: int = MAX_MESSAGE_SIZE,
    enable_retries: bool = True,
    max_attempts: int = 5,
) -> list[tuple[str, Any]]:
    """Generate gRPC channel options with retry policy."""
    service_config = {
        "methodConfig": [{
            "name": [{}],
            "retryPolicy": {
                "maxAttempts": max_attempts,
                "initialBackoff": "0.1s",
                "maxBackoff": "2s",
                "backoffMultiplier": 2.0,
                "retryableStatusCodes": ["UNAVAILABLE", "DEADLINE_EXCEEDED"],
            },
        }]
    }

    return [
        ("grpc.max_receive_message_length", max_receive_message_length),
        ("grpc.max_send_message_length", max_send_message_length),
        ("grpc.enable_retries", 1 if enable_retries else 0),
        ("grpc.service_config", json.dumps(service_config)),
    ]


class TimedObservation:
    """Observation with timing metadata for latency tracking."""

    def __init__(self, timestamp: float, observation: dict, timestep: int, must_go: bool = False):
        self.timestamp = timestamp
        self.observation = observation
        self.timestep = timestep
        self.must_go = must_go

    def get_timestamp(self) -> float:
        return self.timestamp

    def get_observation(self) -> dict:
        return self.observation

    def get_timestep(self) -> int:
        return self.timestep


class TimedAction:
    """Action with timing metadata."""

    def __init__(self, timestamp: float, timestep: int, action: Any):
        self.timestamp = timestamp
        self.timestep = timestep
        self.action = action

    def get_timestamp(self) -> float:
        return self.timestamp

    def get_timestep(self) -> int:
        return self.timestep

    def get_action(self) -> Any:
        return self.action
