#!/bin/bash
# test_connection.sh - Quick test of gRPC connectivity over Tailscale
#
# Usage:
#   On DGX Spark:  ./test_connection.sh server
#   On Robot:      ./test_connection.sh client 100.x.x.x

set -e

ROLE=${1:-"server"}
SERVER_IP=${2:-"100.64.0.1"}
PORT=8080

echo "=== VLA Bridge Connectivity Test ==="

check_tailscale() {
    echo "Checking Tailscale..."
    if ! command -v tailscale &> /dev/null; then
        echo "FAIL: Tailscale not installed"
        exit 1
    fi

    MY_IP=$(tailscale ip -4)
    echo "  My Tailscale IP: $MY_IP"
    echo "  Tailscale status: $(tailscale status | head -1)"
}

test_server() {
    check_tailscale
    echo ""
    echo "Starting test gRPC server on 0.0.0.0:$PORT..."

    python3 -c "
import grpc
from concurrent import futures
import vla_service_pb2 as pb2
import vla_service_pb2_grpc as pb2_grpc

class TestService(pb2_grpc.VLAServiceServicer):
    def Ready(self, request, context):
        print(f'  Received Ready() from {context.peer()}')
        return pb2.ServerInfo(server_id='test-dgx-spark', gpu_info='GB10', ready=True)

server = grpc.server(futures.ThreadPoolExecutor(max_workers=2))
pb2_grpc.add_VLAServiceServicer_to_server(TestService(), server)
server.add_insecure_port('0.0.0.0:$PORT')
server.start()
print(f'  Test server listening on 0.0.0.0:$PORT')
print('  Waiting for client connection...')
server.wait_for_termination()
"
}

test_client() {
    check_tailscale
    echo ""
    echo "Testing connection to $SERVER_IP:$PORT..."

    # Test TCP connectivity first
    echo "  TCP test..."
    if nc -z -w 5 "$SERVER_IP" "$PORT" 2>/dev/null; then
        echo "  TCP: OK (port open)"
    else
        echo "  TCP: Port not reachable yet (server may not be running)"
    fi

    # Test gRPC
    echo "  gRPC test..."
    python3 -c "
import grpc
import sys
sys.path.insert(0, '.')
import vla_service_pb2 as pb2
import vla_service_pb2_grpc as pb2_grpc

channel = grpc.insecure_channel('$SERVER_IP:$PORT')
stub = pb2_grpc.VLAServiceStub(channel)

try:
    info = stub.Ready(pb2.Empty(), timeout=5)
    print(f'  gRPC: OK')
    print(f'  Server ID: {info.server_id}')
    print(f'  GPU: {info.gpu_info}')
    print(f'  Ready: {info.ready}')
except grpc.RpcError as e:
    print(f'  gRPC: FAILED - {e.code()}')
    sys.exit(1)
finally:
    channel.close()
"
}

if [ "$ROLE" = "server" ]; then
    test_server
elif [ "$ROLE" = "client" ]; then
    test_client
else
    echo "Usage: $0 server | client [server-ip]"
    exit 1
fi
