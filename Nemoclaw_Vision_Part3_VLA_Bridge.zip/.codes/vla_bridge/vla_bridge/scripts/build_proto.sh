#!/bin/bash
# build_proto.sh - Generate Python gRPC stubs from proto file
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
PROTO_FILE="$PROJECT_ROOT/proto/vla_service.proto"
OUTPUT_DIR="$PROJECT_ROOT/proto"

echo "Generating gRPC stubs from $PROTO_FILE..."

python -m grpc_tools.protoc \
    -I "$PROJECT_ROOT/proto" \
    --python_out="$OUTPUT_DIR" \
    --grpc_python_out="$OUTPUT_DIR" \
    "$PROTO_FILE"

# Fix import in generated _grpc.py to use relative imports
sed -i.bak 's/import vla_service_pb2/from vla_bridge.proto import vla_service_pb2/' \
    "$OUTPUT_DIR/vla_service_pb2_grpc.py" 2>/dev/null || \
    sed -i '' 's/import vla_service_pb2/from vla_bridge.proto import vla_service_pb2/' \
    "$OUTPUT_DIR/vla_service_pb2_grpc.py"

rm -f "$OUTPUT_DIR/vla_service_pb2_grpc.py.bak"

echo "Generated:"
echo "  $OUTPUT_DIR/vla_service_pb2.py"
echo "  $OUTPUT_DIR/vla_service_pb2_grpc.py"
echo "Done!"
