#!/bin/bash
# setup_tailscale.sh - Set up Tailscale on both machines
# Usage:
#   On DGX Spark: ./setup_tailscale.sh server
#   On Robot:     ./setup_tailscale.sh client <dgx-spark-tailscale-ip>

set -e

ROLE=${1:-"server"}
DGX_IP=${2:-""}

echo "=== Tailscale Setup for VLA Bridge ==="
echo "Role: $ROLE"

# Install Tailscale
if ! command -v tailscale &> /dev/null; then
    echo "Installing Tailscale..."
    curl -fsSL https://tailscale.com/install.sh | sh
fi

# Start Tailscale (will prompt for auth in browser)
echo "Starting Tailscale..."
sudo tailscale up

# Get this machine's Tailscale IP
MY_IP=$(tailscale ip -4)
echo "This machine's Tailscale IP: $MY_IP"

if [ "$ROLE" = "server" ]; then
    echo ""
    echo "=== DGX Spark Server Setup ==="
    echo "Your Tailscale IP: $MY_IP"
    echo ""
    echo "Open port 8080 in the firewall:"
    if command -v ufw &> /dev/null; then
        sudo ufw allow 8080/tcp
        echo "Done (ufw)"
    elif command -v firewall-cmd &> /dev/null; then
        sudo firewall-cmd --permanent --add-port=8080/tcp
        sudo firewall-cmd --reload
        echo "Done (firewalld)"
    else
        echo "No firewall detected, port should be accessible"
    fi
    echo ""
    echo "Start the VLA server with:"
    echo "  python -m vla_bridge.server.run --host=0.0.0.0 --port=8080"

elif [ "$ROLE" = "client" ]; then
    if [ -z "$DGX_IP" ]; then
        echo "Usage: $0 client <dgx-spark-tailscale-ip>"
        exit 1
    fi

    echo ""
    echo "=== Robot Client Setup ==="
    echo "Testing connection to DGX Spark at $DGX_IP..."

    # Test connectivity
    if tailscale ping -c 3 "$DGX_IP"; then
        echo "Connection to DGX Spark: OK"
    else
        echo "WARNING: Cannot reach DGX Spark. Check Tailscale status."
        exit 1
    fi

    # Test gRPC port
    echo "Testing gRPC port 8080..."
    if command -v nc &> /dev/null; then
        if nc -z -w 5 "$DGX_IP" 8080; then
            echo "Port 8080: OPEN"
        else
            echo "WARNING: Port 8080 not reachable. Start the VLA server first."
        fi
    fi

    # Save config
    CONFIG_FILE="$(dirname "$0")/../configs/connection.yaml"
    mkdir -p "$(dirname "$CONFIG_FILE")"
    cat > "$CONFIG_FILE" << EOF
# Auto-generated connection config
dgx_spark_ip: $DGX_IP
dgx_spark_port: 8080
robot_local_ip: $MY_IP
tailscale: true
EOF
    echo "Config saved to: $CONFIG_FILE"
    echo ""
    echo "Start the robot client with:"
    echo "  python -m vla_bridge.client.run --server_address=$DGX_IP:8080"
fi

echo ""
echo "=== Tailscale Status ==="
tailscale status
