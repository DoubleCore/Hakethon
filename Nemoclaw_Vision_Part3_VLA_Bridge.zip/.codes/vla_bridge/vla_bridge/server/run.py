"""Entry point to start VLA server on DGX Spark.

Usage:
    python -m vla_bridge.server.run \\
        --host 0.0.0.0 \\
        --port 8080 \\
        --policy_type openvla \\
        --pretrained_path /path/to/model \\
        --fps 30
"""

import argparse
import logging

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)


def main():
    parser = argparse.ArgumentParser(description="VLA Policy Server (DGX Spark)")
    parser.add_argument("--host", default="0.0.0.0", help="Bind address (0.0.0.0 for Tailscale)")
    parser.add_argument("--port", type=int, default=8080, help="gRPC port")
    parser.add_argument("--policy_type", default="openvla", help="VLA model type")
    parser.add_argument("--pretrained_path", default="", help="Path to pretrained model")
    parser.add_argument("--device", default="cuda:0", help="Inference device")
    parser.add_argument("--fps", type=int, default=30, help="Target control frequency")
    parser.add_argument("--actions_per_chunk", type=int, default=50, help="Actions per chunk")
    args = parser.parse_args()

    from vla_bridge.server.vla_server import VLAServiceServicer

    server = VLAServiceServicer(
        host=args.host,
        port=args.port,
        fps=args.fps,
    )
    server.device = args.device
    server.policy_type = args.policy_type
    server.pretrained_path = args.pretrained_path
    server.actions_per_chunk = args.actions_per_chunk

    server.serve()


if __name__ == "__main__":
    main()
