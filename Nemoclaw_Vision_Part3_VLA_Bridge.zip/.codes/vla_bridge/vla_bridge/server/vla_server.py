"""VLA Policy Server - runs on DGX Spark.

Architecture mirrors LeRobot's PolicyServer but adds:
- Language task support for VLA models
- TensorRT-LLM optimization hooks
- Tailscale-aware binding (0.0.0.0)
"""

import logging
import pickle  # nosec
import threading
import time
from concurrent import futures
from queue import Empty, Queue
from typing import Optional

import grpc
import torch

from vla_bridge.common import (
    TimedAction,
    TimedObservation,
    grpc_channel_options,
    receive_bytes_in_chunks,
)

logger = logging.getLogger("vla_server")


class VLAServiceServicer:
    """gRPC service for VLA inference on DGX Spark.

    Data flow:
    1. Client sends Ready() handshake
    2. Client sends SendPolicyConfig() with model info
    3. Client sends SendTask() with natural language instruction
    4. Loop:
       a. Client streams SendObservations() (images + joint states)
       b. Server runs VLA inference
       c. Client calls GetActions() to retrieve action chunk
    """

    def __init__(self, host: str = "0.0.0.0", port: int = 8080, fps: int = 30):
        self.host = host
        self.port = port
        self.fps = fps
        self.environment_dt = 1.0 / fps

        self.shutdown_event = threading.Event()
        self.observation_queue: Queue[TimedObservation] = Queue(maxsize=1)

        # VLA model state (set by SendPolicyConfig)
        self.device = "cuda:0"
        self.policy = None
        self.policy_type: Optional[str] = None
        self.pretrained_path: Optional[str] = None
        self.actions_per_chunk = 50
        self.current_task: Optional[str] = None

        # Latency tracking
        self._predicted_timesteps_lock = threading.Lock()
        self._predicted_timesteps = set()

    def Ready(self, request, context):
        """Handshake - client confirms server is alive."""
        client_id = context.peer()
        logger.info(f"Client {client_id} connected")
        self.shutdown_event.clear()
        return self._make_server_info()

    def SendPolicyConfig(self, request, context):
        """Receive VLA model configuration from client."""
        self.policy_type = request.policy_type
        self.pretrained_path = request.pretrained_path
        self.device = request.device or "cuda:0"
        self.actions_per_chunk = request.actions_per_chunk or 50

        logger.info(
            f"Policy config received: type={self.policy_type}, "
            f"path={self.pretrained_path}, device={self.device}"
        )

        # TODO: Load VLA model here based on policy_type
        # Example for OpenVLA:
        #   from transformers import AutoModelForVision2Seq, AutoProcessor
        #   self.policy = AutoModelForVision2Seq.from_pretrained(...)
        #   self.processor = AutoProcessor.from_pretrained(...)
        #
        # For Isaac GR00T:
        #   from gr00t.model import Gr00tModel
        #   self.policy = Gr00tModel.from_pretrained(...)
        #
        # TODO: Apply TensorRT-LLM optimization for DGX Spark GB10

        return self._empty()

    def SendTask(self, request, context):
        """Receive natural language task instruction."""
        self.current_task = request.task
        logger.info(f"Task received: '{self.current_task}'")
        return self._empty()

    def SendObservations(self, request_iterator, context):
        """Receive streaming observations from robot client."""
        client_id = context.peer()
        receive_time = time.time()

        received_bytes = receive_bytes_in_chunks(
            request_iterator, log_prefix=f"[Server] Obs from {client_id}"
        )
        timed_obs: TimedObservation = pickle.loads(received_bytes)  # nosec

        obs_ts = timed_obs.get_timestamp()
        latency_ms = (receive_time - obs_ts) * 1000

        logger.debug(
            f"Obs #{timed_obs.get_timestep()} | "
            f"One-way latency: {latency_ms:.1f}ms"
        )

        # Only keep latest observation (same as LeRobot)
        if self.observation_queue.full():
            self.observation_queue.get_nowait()
        self.observation_queue.put(timed_obs)

        return self._empty()

    def GetActions(self, request, context):
        """Run VLA inference and return action chunk."""
        try:
            obs = self.observation_queue.get(timeout=2.0)
            logger.info(f"Running VLA inference for obs #{obs.get_timestep()}")

            start = time.perf_counter()

            # TODO: Replace with actual VLA inference
            action_chunk = self._predict_vla_actions(obs)

            inference_time_ms = (time.perf_counter() - start) * 1000

            actions_bytes = pickle.dumps(action_chunk)

            # Return action chunk with timing metadata
            from vla_bridge.proto import vla_service_pb2 as pb2
            return pb2.ActionChunk(
                data=actions_bytes,
                inference_time_ms=inference_time_ms,
            )

        except Empty:
            return self._action_chunk_empty()
        except Exception as e:
            logger.error(f"Inference error: {e}")
            return self._action_chunk_empty()

    def _predict_vla_actions(self, obs: TimedObservation) -> list[TimedAction]:
        """Run VLA model inference.

        TODO: Implement based on your VLA model choice:
        - OpenVLA: vision-language -> action tokens -> continuous actions
        - Isaac GR00T: NVIDIA's robot foundation model
        """
        if self.policy is None:
            # Placeholder: return dummy actions for testing connectivity
            logger.warning("No VLA model loaded, returning dummy actions")
            dummy_action = torch.zeros(7)  # 7-DOF arm
            return [
                TimedAction(
                    timestamp=obs.get_timestamp() + i * self.environment_dt,
                    timestep=obs.get_timestep() + i,
                    action=dummy_action,
                )
                for i in range(self.actions_per_chunk)
            ]

        # Real VLA inference would go here:
        # observation = obs.get_observation()  # dict with images, joint_states
        # images = observation["images"]
        # state = observation["state"]
        # prompt = f"In: What action should the robot take to {self.current_task}?\nOut:"
        #
        # inputs = self.processor(prompt, images=images, ...)
        # actions = self.policy.predict_action(inputs)
        # return self._time_action_chunk(obs.get_timestamp(), actions, obs.get_timestep())
        raise NotImplementedError("Implement VLA inference for your model")

    def serve(self):
        """Start the gRPC server."""
        from vla_bridge.proto import vla_service_pb2_grpc as pb2_grpc

        server = grpc.server(
            futures.ThreadPoolExecutor(max_workers=4),
            options=grpc_channel_options(),
        )
        pb2_grpc.add_VLAServiceServicer_to_server(self, server)
        server.add_insecure_port(f"{self.host}:{self.port}")

        logger.info(f"VLA Server starting on {self.host}:{self.port}")
        logger.info(f"Device: {self.device}")

        # Log GPU info
        if torch.cuda.is_available():
            logger.info(f"GPU: {torch.cuda.get_device_name(0)}")
            logger.info(f"GPU Memory: {torch.cuda.get_device_properties(0).total_mem / 1e9:.1f} GB")

        server.start()
        server.wait_for_termination()

    # --- Helper methods ---

    def _make_server_info(self):
        from vla_bridge.proto import vla_service_pb2 as pb2
        gpu_info = ""
        if torch.cuda.is_available():
            gpu_info = torch.cuda.get_device_name(0)
        return pb2.ServerInfo(
            server_id="dgx-spark-vla",
            gpu_info=gpu_info,
            ready=True,
        )

    def _empty(self):
        from vla_bridge.proto import vla_service_pb2 as pb2
        return pb2.Empty()

    def _action_chunk_empty(self):
        from vla_bridge.proto import vla_service_pb2 as pb2
        return pb2.ActionChunk(data=b"")


if __name__ == "__main__":
    import argparse
    logging.basicConfig(level=logging.INFO)

    parser = argparse.ArgumentParser(description="VLA Policy Server")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8080)
    args = parser.parse_args()

    server = VLAServiceServicer(host=args.host, port=args.port)
    server.serve()
