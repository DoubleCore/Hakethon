"""Entry point to start VLA robot client.

Usage:
    python -m vla_bridge.client.run \\
        --server_address 100.64.0.1:8080 \\
        --task "fold the t-shirt" \\
        --robot_type so100_follower \\
        --robot_port /dev/ttyUSB0
"""

import argparse
import logging

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)


def main():
    parser = argparse.ArgumentParser(description="VLA Robot Client")
    parser.add_argument("--server_address", required=True, help="DGX Spark Tailscale IP:port")
    parser.add_argument("--task", default="", help="Natural language task instruction")
    parser.add_argument("--robot_type", default="so100_follower", help="Robot type")
    parser.add_argument("--robot_port", default="/dev/ttyUSB0", help="Robot serial port")
    parser.add_argument("--policy_type", default="openvla", help="VLA model type")
    parser.add_argument("--pretrained_path", default="", help="Model path")
    parser.add_argument("--device", default="cpu", help="Client-side device")
    parser.add_argument("--fps", type=int, default=30, help="Control frequency")
    parser.add_argument("--actions_per_chunk", type=int, default=50)
    parser.add_argument("--aggregate_fn", default="weighted_average")
    args = parser.parse_args()

    from vla_bridge.client.vla_client import VLARobotClient

    client = VLARobotClient(
        server_address=args.server_address,
        policy_type=args.policy_type,
        pretrained_path=args.pretrained_path,
        device=args.device,
        actions_per_chunk=args.actions_per_chunk,
        fps=args.fps,
        aggregate_fn_name=args.aggregate_fn,
    )

    # TODO: Create robot instance from LeRobot
    # from lerobot.robots import make_robot_from_config
    # robot = make_robot_from_config(...)
    # robot.connect()

    # For now, test connectivity with dummy robot
    logger.info("Testing connectivity to DGX Spark...")

    try:
        client.start(task=args.task)
        logger.info("Connection test successful!")
        client.stop()
    except Exception as e:
        logger.error(f"Connection test failed: {e}")


if __name__ == "__main__":
    main()
