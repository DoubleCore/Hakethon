"""VLA Robot Client - runs on the machine connected to the robotic arm.

Communicates with DGX Spark VLA server over Tailscale via gRPC.
Mirrors LeRobot's RobotClient pattern with VLA extensions.
"""

import logging
import pickle  # nosec
import threading
import time
from queue import Queue
from typing import Optional

import grpc
import torch

from vla_bridge.common import (
    TimedAction,
    TimedObservation,
    grpc_channel_options,
    send_bytes_in_chunks,
)

logger = logging.getLogger("vla_client")

# Aggregate functions for action queue merging (same as LeRobot)
AGGREGATE_FUNCTIONS = {
    "weighted_average": lambda old, new: 0.3 * old + 0.7 * new,
    "latest_only": lambda old, new: new,
    "average": lambda old, new: 0.5 * old + 0.5 * new,
    "conservative": lambda old, new: 0.7 * old + 0.3 * new,
}


class VLARobotClient:
    """gRPC client for VLA-based robot control.

    Two threads:
    1. Action receiver: polls GetActions() from DGX Spark
    2. Control loop: captures observations, sends to server, executes actions

    Usage:
        client = VLARobotClient(server_address="100.64.0.1:8080")
        client.start(task="fold the red t-shirt")
        # Control loop runs until interrupted
        client.stop()
    """

    def __init__(
        self,
        server_address: str = "100.64.0.1:8080",
        policy_type: str = "openvla",
        pretrained_path: str = "",
        device: str = "cuda:0",
        actions_per_chunk: int = 50,
        fps: int = 30,
        aggregate_fn_name: str = "weighted_average",
    ):
        self.server_address = server_address
        self.fps = fps
        self.environment_dt = 1.0 / fps
        self.actions_per_chunk = actions_per_chunk
        self.aggregate_fn = AGGREGATE_FUNCTIONS.get(aggregate_fn_name, AGGREGATE_FUNCTIONS["weighted_average"])

        # Connect to DGX Spark via Tailscale
        self.channel = grpc.insecure_channel(
            server_address,
            grpc_channel_options(
                initial_backoff=f"{self.environment_dt:.4f}s",
            ),
        )
        from vla_bridge.proto import vla_service_pb2_grpc as pb2_grpc
        self.stub = pb2_grpc.VLAServiceStub(self.channel)

        self.shutdown_event = threading.Event()

        # Action queue management
        self.action_queue: Queue[TimedAction] = Queue()
        self.action_queue_lock = threading.Lock()
        self.latest_action_lock = threading.Lock()
        self.latest_action = -1
        self.action_chunk_size = 1

        # Barrier for synchronized thread start
        self.start_barrier = threading.Barrier(2)

        # Must-go mechanism (same as LeRobot)
        self.must_go = threading.Event()
        self.must_go.set()

        logger.info(f"Client initialized, target: {server_address}")

    def start(self, task: str = "") -> bool:
        """Handshake with VLA server and send configuration."""
        try:
            from vla_bridge.proto import vla_service_pb2 as pb2

            # 1. Handshake
            server_info = self.stub.Ready(pb2.Empty())
            logger.info(
                f"Connected to server: {server_info.server_id} "
                f"GPU: {server_info.gpu_info}"
            )

            # 2. Send policy config
            self.stub.SendPolicyConfig(pb2.PolicyConfig(
                policy_type=self.policy_type,
                pretrained_path=self.pretrained_path,
                device=device,
                actions_per_chunk=self.actions_per_chunk,
            ))
            logger.info("Policy config sent")

            # 3. Send task instruction (VLA-specific!)
            if task:
                self.stub.SendTask(pb2.TaskInstruction(task=task))
                logger.info(f"Task sent: '{task}'")

            self.shutdown_event.clear()
            return True

        except grpc.RpcError as e:
            logger.error(f"Connection failed: {e}")
            return False

    def stop(self):
        """Stop the client and close connection."""
        self.shutdown_event.set()
        self.channel.close()
        logger.info("Client stopped")

    # --- Observation Sending ---

    def send_observation(self, obs: TimedObservation) -> bool:
        """Stream observation to DGX Spark server."""
        from vla_bridge.proto import vla_service_pb2 as pb2

        obs_bytes = pickle.dumps(obs)
        obs_iterator = send_bytes_in_chunks(
            obs_bytes, pb2.Observation,
            log_prefix=f"[Client] Obs #{obs.get_timestep()}",
        )

        try:
            self.stub.SendObservations(obs_iterator)
            return True
        except grpc.RpcError as e:
            logger.error(f"Send obs failed: {e}")
            return False

    # --- Action Receiving ---

    def receive_actions(self):
        """Thread: continuously poll GetActions() from server."""
        from vla_bridge.proto import vla_service_pb2 as pb2

        self.start_barrier.wait()
        logger.info("Action receiver thread started")

        while not self.shutdown_event.is_set():
            try:
                response = self.stub.GetActions(pb2.Empty())
                if not response.data:
                    continue

                timed_actions: list[TimedAction] = pickle.loads(response.data)  # nosec
                self._aggregate_action_queues(timed_actions)
                self.must_go.set()

                logger.info(
                    f"Received {len(timed_actions)} actions | "
                    f"Inference: {response.inference_time_ms:.1f}ms"
                )

            except grpc.RpcError as e:
                logger.error(f"GetActions error: {e}")

    def _aggregate_action_queues(self, incoming: list[TimedAction]):
        """Merge incoming actions with existing queue (LeRobot pattern)."""
        future_queue = Queue()
        with self.action_queue_lock:
            current = {a.get_timestep(): a.get_action() for a in self.action_queue.queue}

        for new_action in incoming:
            with self.latest_action_lock:
                latest = self.latest_action

            if new_action.get_timestep() <= latest:
                continue

            if new_action.get_timestep() in current:
                merged = TimedAction(
                    timestamp=new_action.get_timestamp(),
                    timestep=new_action.get_timestep(),
                    action=self.aggregate_fn(current[new_action.get_timestep()], new_action.get_action()),
                )
                future_queue.put(merged)
            else:
                future_queue.put(new_action)

        with self.action_queue_lock:
            self.action_queue = future_queue

    # --- Control Loop ---

    def control_loop(self, robot, task: str = ""):
        """Main control loop: capture obs -> send to server -> execute actions.

        Args:
            robot: LeRobot robot instance (e.g., SO100Follower)
            task: Natural language task for VLA
        """
        self.start_barrier.wait()
        logger.info("Control loop started")

        while not self.shutdown_event.is_set():
            loop_start = time.perf_counter()

            # (1) Execute pending actions
            with self.action_queue_lock:
                if not self.action_queue.empty():
                    timed_action = self.action_queue.get_nowait()
                    action_dict = self._tensor_to_action_dict(
                        timed_action.get_action(), robot
                    )
                    robot.send_action(action_dict)
                    with self.latest_action_lock:
                        self.latest_action = timed_action.get_timestep()

            # (2) Capture and send observation
            with self.action_queue_lock:
                queue_size = self.action_queue.qsize()
                should_send = queue_size / max(self.action_chunk_size, 1) <= 0.5

            if should_send:
                raw_obs = robot.get_observation()
                with self.latest_action_lock:
                    ts = max(self.latest_action, 0)

                timed_obs = TimedObservation(
                    timestamp=time.time(),
                    observation=raw_obs,
                    timestep=ts,
                )

                with self.action_queue_lock:
                    timed_obs.must_go = self.must_go.is_set() and self.action_queue.empty()
                if timed_obs.must_go:
                    self.must_go.clear()

                self.send_observation(timed_obs)

            # Sleep to maintain target FPS
            elapsed = time.perf_counter() - loop_start
            time.sleep(max(0, self.environment_dt - elapsed))

    def _tensor_to_action_dict(self, action_tensor: torch.Tensor, robot) -> dict:
        """Convert action tensor to robot action dict."""
        return {key: action_tensor[i].item() for i, key in enumerate(robot.action_features)}

    def run(self, robot, task: str = ""):
        """Start both threads and run the control loop."""
        if not self.start(task=task):
            logger.error("Failed to start, aborting")
            return

        receiver_thread = threading.Thread(target=self.receive_actions, daemon=True)
        receiver_thread.start()

        try:
            self.control_loop(robot, task=task)
        finally:
            self.stop()
            receiver_thread.join()
