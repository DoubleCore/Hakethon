"""Shared configuration for VLA Bridge."""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class TailscaleConfig:
    """Tailscale network configuration."""
    use_tailscale: bool = True
    # Leave empty to auto-detect via `tailscale ip -4`
    server_tailscale_ip: Optional[str] = None
    client_tailscale_ip: Optional[str] = None


@dataclass
class VLAServiceConfig:
    """Configuration for VLA gRPC service."""
    host: str = "0.0.0.0"  # Bind to all interfaces for Tailscale
    port: int = 8080
    max_message_size: int = 4 * 1024 * 1024  # 4MB, same as LeRobot
    chunk_size: int = 2 * 1024 * 1024  # 2MB chunks for observation streaming
    enable_retries: bool = True
    max_retry_attempts: int = 5

    @property
    def address(self) -> str:
        return f"{self.host}:{self.port}"


@dataclass
class VLAInferenceConfig:
    """VLA model inference configuration (DGX Spark side)."""
    policy_type: str = "openvla"  # openvla, gr00t, etc.
    pretrained_path: str = ""
    device: str = "cuda:0"
    actions_per_chunk: int = 50
    fps: int = 30

    @property
    def environment_dt(self) -> float:
        return 1.0 / self.fps


@dataclass
class RobotClientConfig:
    """Robot client configuration (robot arm side)."""
    server_address: str = "100.64.0.1:8080"  # DGX Spark Tailscale IP
    robot_type: str = "so100_follower"
    robot_port: str = "/dev/ttyUSB0"
    task: str = ""
    fps: int = 30
    actions_per_chunk: int = 50
    aggregate_fn: str = "weighted_average"  # weighted_average, latest_only

    @property
    def environment_dt(self) -> float:
        return 1.0 / self.fps
