#!/bin/bash
source ~/miniconda3/etc/profile.d/conda.sh
conda activate base
cd /home/xsuper/.codes/vla_bridge
PYTHONPATH=/home/xsuper/.codes/vla_bridge/..:$PYTHONPATH python -m vla_bridge.server.run --host 0.0.0.0 --port 8080
