# VLA Bridge - DGX Spark <--> Robotic Arm

gRPC communication bridge between remote DGX Spark (VLA inference) and local robotic arm, over Tailscale mesh network.

## Architecture

```
DGX Spark (Remote)                    Robot (Local)
┌──────────────────┐    Tailscale     ┌──────────────────┐
│  VLA Policy      │◄──WireGuard──►   │  Robot Client    │
│  Server          │    gRPC          │                  │
│  (GB10 GPU)      │                  │  Camera + Arm    │
│  100.x.x.x:8080  │                  │  100.x.x.x       │
└──────────────────┘                  └──────────────────┘
```

## Quick Start

### 1. Tailscale Setup (both machines)

```bash
# Install on both DGX Spark and robot machine
curl -fsSL https://tailscale.com/install.sh | sh
sudo tailscale up

# Verify connectivity
tailscale ping <peer-tailscale-ip>
```

### 2. Start Server (DGX Spark)

```bash
python -m vla_bridge.server.run \
    --host=0.0.0.0 \
    --port=8080 \
    --policy_type=openvla \
    --pretrained_path=/path/to/openvla-7b
```

### 3. Start Client (Robot Machine)

```bash
python -m vla_bridge.client.run \
    --server_address=100.x.x.x:8080 \
    --robot_type=so100_follower \
    --robot_port=/dev/ttyUSB0 \
    --task="fold the t-shirt" \
    --fps=30
```

## Connection Methods

### Option A: SSH Tunnel (Recommended)

Due to symmetric NAT issues with Tailscale, SSH tunneling provides the most reliable connection:

**1. Create SSH tunnel on robot machine:**
```bash
# Basic tunnel
ssh -fN -L 18080:localhost:8080 -p 6079 xsuper@106.13.186.155

# With auto-reconnect (add to ~/.ssh/config):
Host spark
    HostName 106.13.186.155
    Port 6079
    User xsuper
    LocalForward 18080 localhost:8080
    ServerAliveInterval 60
    ServerAliveCountMax 3

# Then just run:
ssh -fN spark
```

**2. Connect client via tunnel:**
```bash
python -m vla_bridge.client.run \
    --server_address=localhost:18080 \
    --robot_type=so100_follower \
    --task="pick up the red block"
```

**Useful commands:**
```bash
# Check if tunnel is running
ss -tln | grep 18080

# Kill tunnel
pkill -f "ssh.*18080:localhost:8080"

# Test gRPC connection
python -c "
import grpc
from vla_bridge.proto import vla_service_pb2 as pb2
from vla_bridge.proto import vla_service_pb2_grpc as pb2_grpc
channel = grpc.insecure_channel('localhost:18080')
stub = pb2_grpc.VLAServiceStub(channel)
print('Connected:', stub.Ready(pb2.Empty(), timeout=10).server_id)
"
```

### Option B: Tailscale Direct

If Tailscale works in your network environment:
```bash
# Check connectivity
tailscale status
tailscale ping <peer-tailscale-ip>

# Connect directly
python -m vla_bridge.client.run --server_address=100.118.174.96:8080 ...
```

## Troubleshooting

### Tailscale ping works but TCP fails
This is caused by symmetric NAT. Use SSH tunnel (Option A) instead.

### Proxy interference
If you have a local proxy, disable it for Tailscale IPs:
```bash
export no_proxy=100.0.0.0/8,$no_proxy
```

### Server not responding
```bash
# Check server status
ssh spark "ss -tln | grep 8080"

# Check logs
ssh spark "tail -f /tmp/vla_server.log"
```
