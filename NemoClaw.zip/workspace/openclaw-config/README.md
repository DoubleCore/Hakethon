# OpenClaw配置转移说明

本目录包含了从OpenClaw项目转移到NemoClaw的配置文件和相关文档。

## 📁 目录结构

```
openclaw-config/
├── README.md                      # 本说明文件
├── USER.md                        # 用户配置和协作偏好
├── IDENTITY.md                    # 代理身份配置
├── SOUL.md                        # 核心原则和执行规则
├── TOOLS.md                       # 工具使用策略
├── BOOTSTRAP.md                   # 初始化引导模板
├── HEARTBEAT.md                   # 心跳任务模板
├── AGENTS.md                      # Agent工作流定义
└── memory/                        # 长期记忆目录
    ├── xguard-service.md          # XGuard安全审查服务配置
    └── agent-status.md            # Agent状态与环境配置
```

## 🎯 配置文件说明

### 核心身份配置

- **IDENTITY.md**: 定义了代理的名称（龙虾）、角色、类型和核心职责
- **USER.md**: 定义了用户偏好、工作模式、协作偏好等
- **SOUL.md**: 核心工作原则、沟通风格、执行规则和边界

### 工作策略

- **TOOLS.md**: 文件策略、读取策略、执行策略和安全策略
- **AGENTS.md**: 代理的使命、核心工作流程和工作原则

### 模板文件

- **BOOTSTRAP.md**: 新工作区初始化引导模板
- **HEARTBEAT.md**: 心跳任务配置模板

### 记忆文件

- **memory/xguard-service.md**: XGuard安全审查服务的状态和配置
- **memory/agent-status.md**: 运行环境、软件栈、服务状态等详细信息

## 🔧 使用建议

1. **直接使用**: 这些配置文件可以直接在NemoClaw项目中使用
2. **定制调整**: 根据NemoClaw的具体需求进行相应调整
3. **版本控制**: 建议将这些配置文件纳入Git版本控制

## 📌 注意事项

- 部分配置包含了特定的环境信息（如IP地址、服务端口等），在部署到新环境时需要更新
- 某些配置可能包含敏感信息，请在公开前进行清理
- 建议定期更新memory目录中的状态信息

## 🔗 相关资源

- **Skills目录**: 飞书相关的skills已复制到 `../../.agents/skills/lark-*`
- **主配置**: NemoClaw主配置文件位于 `NemoClaw/CLAUDE.md`
- **文档**: 更多NemoClaw相关文档请查看 `docs/` 目录

---

*转移日期: 2026-04-09*
*源项目: OpenClaw*
*目标项目: NemoClaw*
