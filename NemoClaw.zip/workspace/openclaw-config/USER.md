# USER

preferred_name: 项目负责人
language_preference: 中文为主
timezone: Asia/Shanghai

working_profile:
- 我们当前在做一个让 OpenClaw 操作机器人的工具
- 机器人的核心任务之一是执行拍照
- 机器人当前已经在运行中，后续会持续接收拍照、巡检和状态反馈相关任务
- 我们现在处于初始化阶段，需要先把长期协作规则写清楚

collaboration_preferences:
- 不要空话，要直接进入任务
- 不确定的地方要明确说清，不要假设
- 输出要能直接用于执行、配置或验收
- 机器人相关任务必须优先考虑安全边界
- 涉及执行动作时，要先确认前置条件、当前状态和预期结果
