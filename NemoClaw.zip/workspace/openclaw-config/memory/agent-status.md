# Agent 状态与环境配置

> 最后更新: 2026-04-06 18:47 (Asia/Shanghai)

## 1. 运行环境

| 项目 | 值 |
|---|---|
| 主机名 | spark-b860 |
| 架构 | aarch64 (ARM64) |
| 内核 | Linux 6.14.0-1015-nvidia (Ubuntu) |
| CPU | 20 核 |
| 内存 | 119 GiB 总量，~114 GiB 可用 |
| 磁盘 | 3.7 TiB NVMe，已用 1.2 TiB，剩余 2.4 TiB (33%) |
| 局域网 IP | 192.168.110.79 |
| Docker 网桥 | 172.17.0.1, 172.18.0.1 |
| Tailscale | 未启用 |

## 2. 软件栈

| 组件 | 版本 |
|---|---|
| OpenClaw | 2026.4.2 (有更新可用: 2026.4.5) |
| Node.js | v24.14.1 |
| Python | 3.12.3 |
| Docker | 28.5.1 |

## 3. OpenClaw 配置

| 项目 | 状态 |
|---|---|
| Gateway | 本地运行，ws://127.0.0.1:18789，systemd 托管 (active) |
| 通信渠道 | 飞书 (feishu) |
| 默认模型 | zai/glm-5.1 (203k ctx) |
| Agent 数量 | 1 (main) |
| 心跳间隔 | 30 分钟 |
| Memory | 已初始化，向量检索就绪 |
| Node service | 未安装 (无 systemd node 服务) |
| Tailscale | 关闭 |

## 4. 已加载飞书插件

- feishu_doc — 云文档读写
- feishu_chat — 即时通讯
- feishu_wiki — 知识库
- feishu_drive — 云空间文件管理
- feishu_bitable — 多维表格

## 5. 已安装 Skills (飞书相关)

lark-approval, lark-base, lark-calendar, lark-contact, lark-doc, lark-drive, lark-event, lark-im, lark-mail, lark-minutes, lark-openapi-explorer, lark-shared, lark-sheets, lark-skill-maker, lark-task, lark-vc, lark-whiteboard, lark-wiki, lark-workflow-meeting-summary, lark-workflow-standup-report

## 6. 已安装 Skills (通用)

clawflow, clawflow-inbox-triage, clawhub, coding-agent, healthcheck, node-connect, skill-creator, tmux, weather

## 7. GPU

| 项目 | 值 |
|---|---|
| GPU | NVIDIA GB10 |
| 驱动 | 580.126.09 |
| CUDA | 13.0 |
| 显存 | 不支持查询 (嵌入式 GPU) |
| 温度/功耗 | 50°C, 5W (空闲) |
| GPU 进程 | 无 |

## 8. Docker 环境

**容器：**
- `funny_gauss` — nvcr.io/nvidia/deepstream:8.0-triton-arm-sbsa (状态: Created，未运行)

**Docker 网络：**
- bridge / host / none (默认)
- `openshell-cluster-openshell` (自定义桥接)

**关键镜像：**
- `vllm/vllm-openai:latest` (33.8GB) — LLM 推理服务
- `vllm/vllm-openai:gemma4-cu130` (31.1GB) — Gemma4 模型
- `nvcr.io/nvidia/deepstream:8.0-triton-arm-sbsa` (33.6GB) — 视频流处理
- `nvidia/openshell/cluster:0.0.22` + `gateway:0.0.22` — OpenShell 集群

## 9. 运行中的服务

| 端口 | 进程 | 说明 |
|---|---|---|
| 18789 | openclaw-gateway | OpenClaw Gateway |
| 18791 | openclaw-gateway | Gateway 管理 |
| 50051 | python server.py | gRPC 测试服务 (~/grpc_test/) |
| 9999 | python3 upload_server.py | HTTP 文件上传服务 (保存到 ~/) |
| 11000 | 未知 | 待确认 |
| 22 | sshd | SSH |
| 631 | cupsd | 打印服务 |

**gRPC 测试服务** (`~/grpc_test/`):
- `test.proto` — protobuf 定义
- `server.py` — gRPC 服务端
- `test_pb2.py` / `test_pb2_grpc.py` — 生成的桩代码

**HTTP 上传服务** (`/tmp/upload_server.py`):
- PUT 方法上传文件到 ~/ 目录

## 10. 机器人相关 — 当前进展

### 10.1 MuJoCo 仿真 gRPC 框架 (已搭建)

**位置:** `/home/xsuper/mujoco_grpc_client/`

已定义 `mujoco_sim.proto`，包含完整仿真控制接口：

| RPC | 功能 | 状态 |
|---|---|---|
| `Reset` | 加载 MJCF 模型并重置仿真 | proto + client 已写 |
| `Step` | 执行一步仿真（含动作、可选渲染） | proto + client 已写 |
| `GetObservation` | 获取当前观测（关节位置/速度/力/位姿） | proto 已定义 |
| `Close` | 关闭仿真 | proto 已定义 |

**Observation 包含：**
- joint_position, joint_velocity, actuator_force
- body_position, body_orientation (四元数)
- sim_time

**Step 可返回：** rendered_image (JPEG/PNG) → 即仿真中的"拍照"能力

**Client (`client.py`):** 已实现 SimClient 类，支持 reset/step/close，有随机动作 demo。

**当前状态：** 框架已搭建，client 端代码已写好，但 **gRPC server 端（运行在机器人上的仿真服务）尚未确认是否已部署**。`main.py` 仍为空壳。

### 10.2 gRPC 通信测试 (`~/grpc_test/`)

基础 Echo 服务，已验证 gRPC 通信链路可用（端口 50051 正在监听）。

### 10.3 其他相关项目

| 项目 | 位置 | 说明 |
|---|---|---|
| NemoClaw | ~/NemoClaw/ | 完整 Node.js 项目，含 Docker/k8s 部署，可能是机器人调度框架 |
| xguard | ~/xguard/ | 训练脚本 + 模型，正在跑 training_v10.log，可能是安全守卫模型 |
| vllm + Gemma4 | 多个 vllm 目录 | 本地 LLM 推理服务 |
| deepstream | Docker 镜像 | NVIDIA 视频流处理（未启动） |

### 10.4 待推进事项

1. **确认 MuJoCo gRPC Server 部署位置** — 在本机还是远程机器人上？
2. **从 OpenClaw 调用 gRPC Client** — 编写 Python 脚本或封装为 Skill
3. **实现拍照流程** — 调用 Step(render=true) 获取图像 → 保存/上传
4. **接入真实机器人** — 仿真验证后，对接实体机器人控制接口
5. **安全边界** — 定义哪些动作需要人工确认
6. **了解 NemoClaw 架构** — 确认与 OpenClaw 的协作关系

## 11. 当前工作区文件

```
AGENTS.md      — Agent 核心工作流定义
IDENTITY.md    — 身份信息 (龙虾 🦞)
SOUL.md        — 行为准则与沟通风格
TOOLS.md       — 文件/执行/安全策略
USER.md        — 用户偏好
HEARTBEAT.md   — 心跳任务 (当前为空)
BOOTSTRAP.md   — 初始化引导 (待清理)
memory/        — 长期记忆目录 (本文件)
```
