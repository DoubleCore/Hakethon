#!/usr/bin/env python3
"""Nemotron-3-Nano-30B - FastAPI HTTP Inference Service.

Serves the nemotron model as an OpenAI-compatible chat API.
Usage: python nemotron_server.py [--port 8087] [--model-path /home/xsuper/models/nemotron-3-nano-30b-a3b]
"""
import argparse
import time
import torch
from fastapi import FastAPI
from pydantic import BaseModel, Field
import uvicorn
from transformers import AutoModelForCausalLM, AutoTokenizer

app = FastAPI(title="Nemotron Chat API", version="1.0")

model = None
tokenizer = None
load_time: float = 0


class Message(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    messages: list[Message]
    max_tokens: int = Field(2048, ge=1, le=8192)
    temperature: float = Field(0.7, ge=0.0, le=2.0)
    top_p: float = Field(0.9, ge=0.0, le=1.0)


class ChatResponse(BaseModel):
    content: str
    role: str = "assistant"
    model: str = "nemotron-3-nano-30b-a3b"
    inference_time: float


@app.get("/health")
def health():
    return {
        "status": "ok" if model else "loading",
        "model_load_time": load_time,
        "model": "nemotron-3-nano-30b-a3b",
    }


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    import traceback as tb
    t0 = time.time()
    try:
        messages = [{"role": m.role, "content": m.content} for m in req.messages]
        input_text = tokenizer.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True
        )
        inputs = tokenizer(input_text, return_tensors="pt").to(model.device)

        with torch.inference_mode():
            outputs = model.generate(
                **inputs,
                max_new_tokens=req.max_tokens,
                do_sample=req.temperature > 0,
                temperature=req.temperature if req.temperature > 0 else None,
                top_p=req.top_p if req.temperature > 0 else None,
            )

        generated_ids = outputs[0][inputs["input_ids"].shape[1]:]
        content = tokenizer.decode(generated_ids, skip_special_tokens=True)

        return ChatResponse(
            content=content,
            inference_time=round(time.time() - t0, 3),
        )
    except Exception as e:
        print(f"[ERROR] {e}\n{tb.format_exc()}", flush=True)
        raise


def main():
    global model, tokenizer, load_time

    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8087)
    parser.add_argument("--model-path", default="/home/xsuper/models/nemotron-3-nano-30b-a3b")
    parser.add_argument("--host", default="0.0.0.0")
    args = parser.parse_args()

    print(f"Loading Nemotron model from: {args.model_path}")
    t0 = time.time()

    tokenizer = AutoTokenizer.from_pretrained(args.model_path, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        torch_dtype="auto",
        device_map="auto",
        trust_remote_code=True,
        low_cpu_mem_usage=True,
    ).eval()

    load_time = round(time.time() - t0, 2)
    print(f"Model loaded in {load_time}s")
    print(f"Starting server on {args.host}:{args.port}")
    uvicorn.run(app, host=args.host, port=args.port, log_level="info")


if __name__ == "__main__":
    main()
