#!/usr/bin/env python3
"""Local HTTP proxy + file server with SSH reverse tunnel (auto-reconnect)."""
import paramiko
import threading
import socket
import subprocess
import time
import sys
import os

SSH_HOST = os.environ.get("SSH_HOST", "")
SSH_PORT = int(os.environ.get("SSH_PORT", "22"))
SSH_USER = os.environ.get("SSH_USER", "")
SSH_PASS = os.environ.get("SSH_PASS", "")
PROXY_PORT = 8898
FILE_PORT = 8902
FILE_DIR = "E:\\"
BUF = 131072  # 128KB buffer
SOCK_BUF = 1048576  # 1MB socket buffer

procs = []


def log(msg):
    print(msg, flush=True)


def pipe(src, dst):
    try:
        while True:
            data = src.recv(BUF)
            if not data:
                break
            dst.sendall(data)
    except Exception:
        pass
    for s in (src, dst):
        try:
            s.close()
        except Exception:
            pass


def handle_chan(chan, local_port):
    try:
        sock = socket.create_connection(("127.0.0.1", local_port))
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, SOCK_BUF)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, SOCK_BUF)
    except Exception as e:
        log(f"  [!] Local connect port {local_port} failed: {e}")
        chan.close()
        return
    threading.Thread(target=pipe, args=(chan, sock), daemon=True).start()
    threading.Thread(target=pipe, args=(sock, chan), daemon=True).start()


def run_tunnel(remote_port, local_port, label):
    """One SSH connection per reverse tunnel, auto-reconnect on failure."""
    while True:
        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(SSH_HOST, port=SSH_PORT, username=SSH_USER, password=SSH_PASS, timeout=30)
            transport = client.get_transport()
            transport.set_keepalive(15)
            transport.request_port_forward("127.0.0.1", remote_port)
            log(f"  [{label}] Remote:{remote_port} -> Local:{local_port}  CONNECTED")
            while transport.is_active():
                chan = transport.accept(1)
                if chan is None:
                    continue
                threading.Thread(target=handle_chan, args=(chan, local_port), daemon=True).start()
        except Exception as e:
            log(f"  [{label}] tunnel error: {e}")
        finally:
            try:
                client.close()
            except Exception:
                pass
        log(f"  [{label}] reconnecting in 30s...")
        time.sleep(30)


def main():
    log("=== [1/3] Starting local services ===")

    log(f"  HTTP proxy on :{PROXY_PORT} ...")
    p1 = subprocess.Popen(
        [sys.executable, "-m", "proxy", "--port", str(PROXY_PORT), "--log-level", "WARNING"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    procs.append(p1)

    log(f"  File server (Range support) on :{FILE_PORT} (serving {FILE_DIR}) ...")
    script_dir = os.path.dirname(os.path.abspath(__file__))
    p2 = subprocess.Popen(
        [sys.executable, os.path.join(script_dir, "range_server.py"), FILE_DIR, str(FILE_PORT)],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    procs.append(p2)
    time.sleep(2)

    log("\n=== [2/3] SSH reverse tunnels (auto-reconnect) ===")
    t1 = threading.Thread(target=run_tunnel, args=(PROXY_PORT, PROXY_PORT, "PROXY"), daemon=True)
    t2 = threading.Thread(target=run_tunnel, args=(FILE_PORT, FILE_PORT, "FILES"), daemon=True)
    t1.start()
    t2.start()
    time.sleep(3)

    log(f"\n=== [3/3] READY ===")
    log(f"Tunnels will auto-reconnect on failure.")
    log(f"Ctrl+C to stop.\n")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        log("\nShutting down...")
        for p in procs:
            p.terminate()


if __name__ == "__main__":
    main()
