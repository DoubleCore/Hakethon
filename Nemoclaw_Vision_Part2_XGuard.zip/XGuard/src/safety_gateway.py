#!/usr/bin/env python3
"""Safety Gateway - 前置 XGuard 审核链路。

流程: User -> Gateway -> XGuard 审核 -> 通过则转发至主 LLM -> 返回
                                   未通过则拦截并返回风险信息

提供自定义 /chat 与 OpenAI 兼容的 /v1/chat/completions 入口。

Usage:
    python safety_gateway.py \\
      --port 8088 \\
      --xguard-url http://127.0.0.1:8086 \\
      --llm-url http://127.0.0.1:8087
"""

import argparse
import time
import uuid
from typing import Any, Dict, List

import httpx
import uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="Safety Gateway API", version="1.1")

MODEL_NAME = "Gemma-4-31B-IT-NVFP4"
XGUARD_URL = "http://127.0.0.1:8086"
LLM_URL = "http://127.0.0.1:8087"

# 仅拦截高风险类别，其余放行
BLOCK_TAGS = {
    "pc",   # Pornographic Contraband
    "dc",   # Drug Crimes
    "dw",   # Dangerous Weapons
    "ter",  # Violent Terrorist Activities
    "mc",   # Malicious Code
    "ha",   # Hacker Attack
    "cm",   # Corruption of Minors
    "ma",   # Minor Abuse and Exploitation
    "ext",  # Extremist Ideological Trends
}

DEFAULT_TIMEOUT = httpx.Timeout(10.0, connect=5.0, read=300.0)
http_client: httpx.AsyncClient | None = None


class Message(BaseModel):
    role: str
    content: str


class GatewayRequest(BaseModel):
    messages: list[Message]
    max_tokens: int = Field(4096, ge=1, le=8192)
    temperature: float = Field(0.7, ge=0.0, le=2.0)
    check_response: bool = Field(False, description="同时审查模型回复")


class GatewayResponse(BaseModel):
    content: str
    blocked: bool
    risk_info: dict | None = None
    model: str = ""
    total_time: float = 0
    guard_time: float = 0
    llm_time: float = 0
    llm_tokens: Dict[str, Any] | None = None


class OaiMessage(BaseModel):
    role: str
    content: str


class OaiChatRequest(BaseModel):
    model: str = MODEL_NAME
    messages: list[OaiMessage]
    max_tokens: int | None = Field(2048, ge=1, le=8192)
    temperature: float | None = Field(0.7, ge=0.0, le=2.0)
    top_p: float | None = 0.9
    stream: bool = False


@app.on_event("startup")
async def _startup() -> None:
    # 复用单个客户端，降低连接开销
    global http_client
    http_client = httpx.AsyncClient(timeout=DEFAULT_TIMEOUT, http2=True)


@app.on_event("shutdown")
async def _shutdown() -> None:
    global http_client
    if http_client:
        await http_client.aclose()
        http_client = None


def _ensure_client() -> httpx.AsyncClient:
    # FastAPI 生命周期可能尚未触发时兜底创建一次性客户端
    return http_client or httpx.AsyncClient(timeout=DEFAULT_TIMEOUT, http2=True)


async def _guard(messages: List[Dict[str, str]]) -> tuple[dict, float]:
    client = _ensure_client()
    start = time.perf_counter()
    try:
        resp = await client.post(
            f"{XGUARD_URL}/guard",
            json={"messages": messages, "enable_reasoning": False},
        )
        resp.raise_for_status()
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"XGuard 调用失败: {exc}") from exc
    result = resp.json()
    return result, time.perf_counter() - start


def _is_blocked(guard_result: Dict[str, Any]) -> bool:
    return guard_result.get("risk_tag", "sec") in BLOCK_TAGS


async def _call_llm(
    messages: List[Dict[str, str]],
    max_tokens: int,
    temperature: float,
) -> tuple[str, dict, float, Dict[str, Any] | None]:
    client = _ensure_client()
    start = time.perf_counter()
    try:
        resp = await client.post(
            f"{LLM_URL}/v1/chat/completions",
            json={
                "model": MODEL_NAME,
                "messages": messages,
                "max_tokens": max_tokens,
                "temperature": temperature,
            },
        )
        resp.raise_for_status()
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"LLM 调用失败: {exc}") from exc

    result = resp.json()
    duration = time.perf_counter() - start
    message = (result.get("choices") or [{}])[0].get("message", {})
    content = message.get("content") or ""
    if not content.strip() and message.get("reasoning_content"):
        content = message["reasoning_content"].strip()
    usage = result.get("usage")
    return content, result, duration, usage


def _build_block_message(guard_result: Dict[str, Any]) -> str:
    return (
        "[BLOCKED] 内容安全校验未通过"
        f"\n风险类型: {guard_result.get('risk_label', 'Unknown')}"
        f"\n风险维度: {guard_result.get('risk_dimension', 'Unknown')}"
    )


@app.get("/health")
async def health() -> dict:
    client = _ensure_client()
    xguard_ok = False
    llm_ok = False
    try:
        r = await client.get(f"{XGUARD_URL}/health")
        xguard_ok = r.json().get("status") == "ok"
    except Exception:
        pass
    try:
        r = await client.get(f"{LLM_URL}/health")
        llm_ok = r.json().get("status") == "ok"
    except Exception:
        pass
    return {"xguard": xguard_ok, "llm": llm_ok, "gateway": "ok"}


@app.post("/chat", response_model=GatewayResponse)
async def chat(req: GatewayRequest) -> GatewayResponse:
    t0 = time.time()
    messages_dict = [{"role": m.role, "content": m.content} for m in req.messages]

    guard_result, guard_duration = await _guard(messages_dict)
    guard_time = guard_result.get("inference_time", guard_duration)

    if _is_blocked(guard_result):
        return GatewayResponse(
            content=_build_block_message(guard_result),
            blocked=True,
            risk_info=guard_result,
            total_time=round(time.time() - t0, 3),
            guard_time=guard_time,
        )

    content, llm_result, llm_duration, token_usage = await _call_llm(
        messages_dict, req.max_tokens, req.temperature
    )

    if req.check_response and content:
        response_messages = messages_dict + [{"role": "assistant", "content": content}]
        resp_guard_result, resp_guard_duration = await _guard(response_messages)
        if not resp_guard_result.get("safe", False):
            return GatewayResponse(
                content=_build_block_message(resp_guard_result),
                blocked=True,
                risk_info=resp_guard_result,
                model=llm_result.get("model", ""),
                total_time=round(time.time() - t0, 3),
                guard_time=guard_time + resp_guard_result.get(
                    "inference_time", resp_guard_duration
                ),
                llm_time=llm_duration,
                llm_tokens=token_usage,
            )

    return GatewayResponse(
        content=content,
        blocked=False,
        model=llm_result.get("model", ""),
        total_time=round(time.time() - t0, 3),
        guard_time=guard_time,
        llm_time=llm_duration,
        llm_tokens=token_usage,
    )


@app.get("/v1/models")
async def list_models() -> dict:
    return {
        "object": "list",
        "data": [{"id": MODEL_NAME, "object": "model", "owned_by": "nvidia"}],
    }


@app.post("/v1/chat/completions")
async def oai_chat(req: OaiChatRequest) -> dict:
    t0 = time.time()
    messages_dict = [{"role": m.role, "content": m.content} for m in req.messages]

    guard_result, _ = await _guard(messages_dict)
    if _is_blocked(guard_result):
        return _oai_response(_build_block_message(guard_result), t0)

    content, _, _, _ = await _call_llm(
        messages_dict,
        req.max_tokens or 2048,
        req.temperature if req.temperature is not None else 0.7,
    )
    return _oai_response(content, t0)


def _oai_response(content: str, t0: float) -> dict:
    return {
        "id": f"chatcmpl-{uuid.uuid4().hex[:12]}",
        "object": "chat.completion",
        "created": int(time.time()),
        "model": MODEL_NAME,
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": content},
                "finish_reason": "stop",
            }
        ],
        "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
        "system_fingerprint": f"sg-{int((time.time()-t0)*1000)}ms",
    }


def main() -> None:
    global XGUARD_URL, LLM_URL

    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8088)
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--xguard-url", default="http://127.0.0.1:8086")
    parser.add_argument("--llm-url", default="http://127.0.0.1:8087")
    args = parser.parse_args()

    XGUARD_URL = args.xguard_url
    LLM_URL = args.llm_url

    print(f"Safety Gateway starting on {args.host}:{args.port}")
    print(f"  XGuard: {XGUARD_URL}")
    print(f"  LLM:    {LLM_URL}")
    uvicorn.run(app, host=args.host, port=args.port, log_level="info")


if __name__ == "__main__":
    main()
