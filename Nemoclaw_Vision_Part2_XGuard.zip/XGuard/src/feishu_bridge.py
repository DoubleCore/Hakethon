#!/usr/bin/env python3
"""Feishu Bot Bridge - connects Feishu messaging to Safety Gateway.

Flow: Feishu user message → this bridge → XGuard safety check → Nemotron → reply to Feishu

Usage: python feishu_bridge.py [--port 9000] [--gateway-url http://127.0.0.1:8888]
"""
import argparse
import asyncio
import hashlib
import json
import os
import time
import base64
import traceback
from Crypto.Cipher import AES

import httpx
from fastapi import FastAPI, Request
import uvicorn

# ── Feishu App Credentials (set via environment variables) ──
APP_ID = os.environ.get("FEISHU_APP_ID", "")
APP_SECRET = os.environ.get("FEISHU_APP_SECRET", "")
VERIFICATION_TOKEN = os.environ.get("FEISHU_VERIFICATION_TOKEN", "")
ENCRYPT_KEY = os.environ.get("FEISHU_ENCRYPT_KEY", "")

GATEWAY_URL = "http://127.0.0.1:8888"
FEISHU_API = "https://open.feishu.cn/open-apis"

app = FastAPI(title="Feishu Bridge", version="1.0")

# ── Token cache ──
_tenant_token = {"token": "", "expires": 0}
# ── Dedup: track processed message IDs ──
_seen_msg_ids: dict[str, float] = {}


def log(msg: str):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


# ── AES Decrypt (Feishu encrypt key) ──
def decrypt_feishu(encrypt: str) -> str:
    key = hashlib.sha256(ENCRYPT_KEY.encode()).digest()
    data = base64.b64decode(encrypt)
    iv = data[:16]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    decrypted = cipher.decrypt(data[16:])
    pad = decrypted[-1]
    return decrypted[:-pad].decode("utf-8")


# ── Get tenant_access_token ──
async def get_token() -> str:
    now = time.time()
    if _tenant_token["token"] and _tenant_token["expires"] > now + 60:
        return _tenant_token["token"]
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.post(
            f"{FEISHU_API}/auth/v3/tenant_access_token/internal",
            json={"app_id": APP_ID, "app_secret": APP_SECRET},
        )
    data = r.json()
    _tenant_token["token"] = data["tenant_access_token"]
    _tenant_token["expires"] = now + data.get("expire", 7200)
    log(f"Token refreshed, expires in {data.get('expire', 7200)}s")
    return _tenant_token["token"]


# ── Send reply to Feishu ──
async def reply_message(message_id: str, text: str):
    token = await get_token()
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(
            f"{FEISHU_API}/im/v1/messages/{message_id}/reply",
            headers={"Authorization": f"Bearer {token}"},
            json={
                "content": json.dumps({"text": text}),
                "msg_type": "text",
            },
        )
    result = r.json()
    if result.get("code") != 0:
        log(f"Reply failed: {result}")
    return result


# ── Process message through Safety Gateway ──
async def process_message(user_text: str) -> str:
    try:
        async with httpx.AsyncClient(timeout=300) as client:
            r = await client.post(
                f"{GATEWAY_URL}/v1/chat/completions",
                json={
                    "model": "nemotron-3-nano-30b-a3b",
                    "messages": [{"role": "user", "content": user_text}],
                    "max_tokens": 2048,
                    "temperature": 0.7,
                },
            )
        data = r.json()
        content = data["choices"][0]["message"]["content"]
        # Strip thinking tags if present
        if "</think>" in content:
            content = content.split("</think>", 1)[-1].strip()
        return content
    except Exception as e:
        log(f"Gateway error: {e}\n{traceback.format_exc()}")
        return f"[ERROR] 处理失败: {e}"


# ── Cleanup old message IDs (keep last 10 min) ──
def cleanup_seen():
    cutoff = time.time() - 600
    expired = [k for k, v in _seen_msg_ids.items() if v < cutoff]
    for k in expired:
        del _seen_msg_ids[k]


# ── Background task: process and reply ──
async def _handle_message(msg_id: str, user_text: str, sender: str):
    try:
        log(f"Processing for {sender}: {user_text[:50]}...")
        reply_text = await process_message(user_text)
        log(f"Reply ready ({len(reply_text)} chars): {reply_text[:50]}...")
        result = await reply_message(msg_id, reply_text)
        log(f"Reply sent to {sender}, code={result.get('code')}")
    except Exception as e:
        log(f"Background task error: {e}\n{traceback.format_exc()}")
        try:
            await reply_message(msg_id, f"[ERROR] 处理失败，请稍后重试")
        except Exception:
            pass


# ── Feishu event endpoint ──
@app.post("/feishu/event")
async def feishu_event(request: Request):
    body = await request.json()

    # Handle encrypted events
    if "encrypt" in body:
        decrypted = decrypt_feishu(body["encrypt"])
        body = json.loads(decrypted)

    # URL verification challenge
    if "challenge" in body:
        log("URL verification challenge received")
        return {"challenge": body["challenge"]}

    # Schema v2 event
    header = body.get("header", {})
    event = body.get("event", {})
    event_type = header.get("event_type", "")

    log(f"Event received: type={event_type}, body_keys={list(body.keys())}")

    # Only handle message receive events
    if event_type != "im.message.receive_v1":
        log(f"Ignored event: {event_type}")
        return {"code": 0}

    message = event.get("message", {})
    msg_id = message.get("message_id", "")
    msg_type = message.get("message_type", "")
    chat_type = message.get("chat_type", "")  # "p2p" or "group"

    log(f"Message detail: chat_type={chat_type}, msg_type={msg_type}, mentions={message.get('mentions', [])}")

    # In group chat, only respond when @mentioned; always respond in DM
    if chat_type == "group":
        mentions = message.get("mentions", [])
        if not mentions:
            log(f"[group] Ignored (no @mention)")
            return {"code": 0}

    # Dedup
    if msg_type != "text":
        asyncio.create_task(reply_message(msg_id, "目前只支持文本消息哦~"))
        return {"code": 0}

    # Extract text content
    try:
        content_obj = json.loads(message.get("content", "{}"))
        user_text = content_obj.get("text", "").strip()
    except Exception:
        user_text = ""

    # Strip @mention placeholders from text (e.g., "@_user_1 你好" → "你好")
    import re
    user_text = re.sub(r"@_user_\d+\s*", "", user_text).strip()

    if not user_text:
        return {"code": 0}

    sender = event.get("sender", {}).get("sender_id", {}).get("open_id", "unknown")
    log(f"[{chat_type}] Message from {sender}: {user_text[:50]}...")

    # Fire-and-forget: process in background, return 200 immediately
    asyncio.create_task(_handle_message(msg_id, user_text, sender))
    return {"code": 0}


# ── Feishu callback endpoint ──
@app.post("/feishu/callback")
async def feishu_callback(request: Request):
    body = await request.json()
    if "encrypt" in body:
        decrypted = decrypt_feishu(body["encrypt"])
        body = json.loads(decrypted)
    if "challenge" in body:
        return {"challenge": body["challenge"]}
    return {"code": 0}


@app.get("/health")
async def health():
    return {"status": "ok", "service": "feishu-bridge"}


def main():
    global GATEWAY_URL
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=9000)
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--gateway-url", default="http://127.0.0.1:8888")
    args = parser.parse_args()
    GATEWAY_URL = args.gateway_url

    log(f"Feishu Bridge starting on {args.host}:{args.port}")
    log(f"  Gateway: {GATEWAY_URL}")
    log(f"  Webhook: http://<external-ip>:9079/feishu/event")
    uvicorn.run(app, host=args.host, port=args.port, log_level="info")


if __name__ == "__main__":
    main()
