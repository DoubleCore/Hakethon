#!/usr/bin/env python3
"""HTTP file server with Range request support for resume downloads."""
import os
import sys
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import unquote


class RangeHTTPHandler(BaseHTTPRequestHandler):
    directory = "."

    def do_GET(self):
        path = unquote(self.path.lstrip("/"))
        filepath = os.path.join(self.directory, path)

        if not os.path.isfile(filepath):
            # Directory listing fallback
            if os.path.isdir(filepath or self.directory):
                self._list_dir(filepath or self.directory)
                return
            self.send_error(404, "File not found")
            return

        file_size = os.path.getsize(filepath)
        start = 0
        end = file_size - 1

        range_header = self.headers.get("Range")
        if range_header:
            # Parse Range: bytes=START-END
            range_spec = range_header.replace("bytes=", "").strip()
            parts = range_spec.split("-")
            if parts[0]:
                start = int(parts[0])
            if parts[1]:
                end = int(parts[1])
            end = min(end, file_size - 1)
            length = end - start + 1

            self.send_response(206)
            self.send_header("Content-Range", f"bytes {start}-{end}/{file_size}")
            self.send_header("Content-Length", str(length))
        else:
            length = file_size
            self.send_response(200)
            self.send_header("Content-Length", str(file_size))

        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Type", "application/octet-stream")
        self.end_headers()

        with open(filepath, "rb") as f:
            f.seek(start)
            remaining = length
            buf_size = 131072  # 128KB
            while remaining > 0:
                chunk = f.read(min(buf_size, remaining))
                if not chunk:
                    break
                try:
                    self.wfile.write(chunk)
                except (BrokenPipeError, ConnectionResetError):
                    break
                remaining -= len(chunk)

    def do_HEAD(self):
        path = unquote(self.path.lstrip("/"))
        filepath = os.path.join(self.directory, path)
        if not os.path.isfile(filepath):
            self.send_error(404)
            return
        file_size = os.path.getsize(filepath)
        self.send_response(200)
        self.send_header("Content-Length", str(file_size))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Type", "application/octet-stream")
        self.end_headers()

    def _list_dir(self, dirpath):
        try:
            entries = os.listdir(dirpath or self.directory)
        except OSError:
            self.send_error(403)
            return
        entries.sort()
        body = "<html><body><h1>Directory listing</h1><ul>"
        for e in entries:
            body += f'<li><a href="/{e}">{e}</a></li>'
        body += "</ul></body></html>"
        data = body.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, format, *args):
        pass  # suppress logs


def run(directory, port):
    RangeHTTPHandler.directory = directory
    server = HTTPServer(("0.0.0.0", port), RangeHTTPHandler)
    server.serve_forever()


if __name__ == "__main__":
    d = sys.argv[1] if len(sys.argv) > 1 else "."
    p = int(sys.argv[2]) if len(sys.argv) > 2 else 8900
    print(f"Range HTTP server on :{p} serving {d}")
    run(d, p)
