#!/usr/bin/env python3
"""Gemma-4-31B-IT - FastAPI HTTP Inference Service.

Serves Gemma-4 as an OpenAI-compatible chat API.
Usage: python gemma_server.py [--port 8087] [--model-path /home/xsuper/models/Gemma-4-31B-IT-NVFP4]
"""
import argparse
import time
import torch
from fastapi import FastAPI
from pydantic import BaseModel, Field
import uvicorn
from transformers import AutoModelForCausalLM, AutoTokenizer, AutoProcessor

app = FastAPI(title="Gemma Chat API", version="1.0")

model = None
processor = None
load_time: float = 0
MODEL_NAME = "Gemma-4-31B-IT-NVFP4"


class Message(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    messages: list[Message]
    max_tokens: int = Field(2048, ge=1, le=8192)
    temperature: float = Field(0.7, ge=0.0, le=2.0)
    top_p: float = Field(0.9, ge=0.0, le=1.0)


class ChatResponse(BaseModel):
    content: str
    role: str = "assistant"
    model: str = "Gemma-4-31B-IT-NVFP4"
    inference_time: float


@app.get("/health")
def health():
    return {
        "status": "ok" if model else "loading",
        "model_load_time": load_time,
        "model": MODEL_NAME,
    }


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    import traceback as tb
    t0 = time.time()
    try:
        messages = [{"role": m.role, "content": m.content} for m in req.messages]
        input_text = processor.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True
        )
        inputs = processor(text=input_text, return_tensors="pt").to(model.device)

        with torch.inference_mode():
            outputs = model.generate(
                **inputs,
                max_new_tokens=req.max_tokens,
                do_sample=req.temperature > 0,
                temperature=req.temperature if req.temperature > 0 else None,
                top_p=req.top_p if req.temperature > 0 else None,
            )

        generated_ids = outputs[0][inputs["input_ids"].shape[1]:]
        content = processor.decode(generated_ids, skip_special_tokens=True)

        return ChatResponse(
            content=content,
            inference_time=round(time.time() - t0, 3),
        )
    except Exception as e:
        print(f"[ERROR] {e}\n{tb.format_exc()}", flush=True)
        raise


def main():
    global model, processor, load_time

    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8087)
    parser.add_argument("--model-path", default="/home/xsuper/models/Gemma-4-31B-IT-NVFP4")
    parser.add_argument("--host", default="0.0.0.0")
    args = parser.parse_args()

    print(f"Loading Gemma model from: {args.model_path}")
    t0 = time.time()

    processor = AutoProcessor.from_pretrained(args.model_path, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        torch_dtype=torch.bfloat16,
        device_map="auto",
        trust_remote_code=True,
    ).eval()

    load_time = round(time.time() - t0, 2)
    print(f"Model loaded in {load_time}s")
    print(f"Starting server on {args.host}:{args.port}")
    uvicorn.run(app, host=args.host, port=args.port, log_level="info")


if __name__ == "__main__":
    main()
