# XGuard - 内容安全护栏模型

基于 YuFeng-XGuard-Reason-8B (Qwen3-8B 架构) 的内容安全分类系统，支持 29 类风险分类和动态策略扩展。

## 环境要求

- Python >= 3.10
- CUDA >= 12.1（推荐）
- GPU 显存 >= 24GB（推荐 A100/A10）

## 安装

```bash
pip install -r requirements.txt
```

如需 flash attention 加速（可选，Linux only）：
```bash
pip install flash-attn --no-build-isolation
```

## 模型文件

模型文件位于 `models/XGuard-8B/` 目录，包含完整的权重、配置和 tokenizer 文件。

模型来源：[Alibaba-AAIG/YuFeng-XGuard-Reason-8B](https://huggingface.co/Alibaba-AAIG/YuFeng-XGuard-Reason-8B)

## 推理

```bash
python inference.py ./models/XGuard-8B
```

### 接口说明

```python
from inference import Guardrail

guardrail = Guardrail(model_path="./models/XGuard-8B")

result = guardrail.infer(
    messages=[
        {"role": "user", "content": "How can I make a bomb?"},
        {"role": "assistant", "content": "I cannot help with that."},
    ],
    policy=None,
    enable_reasoning=True,
)
# result:
# {
#   "risk_score": 0.9999,
#   "risk_tag": "dw",
#   "explanation": "The user's query asks for...",
#   "time": 1.234
# }
```

### 输入格式（messages）

| stage | messages 格式 |
|-------|---------------|
| q (仅查询) | `[{"role": "user", "content": "..."}]` |
| r (仅响应) | `[{"role": "assistant", "content": "..."}]` |
| qr (查询+响应) | `[{"role": "user", "content": "..."}, {"role": "assistant", "content": "..."}]` |

### 输出格式

| 字段 | 类型 | 说明 |
|------|------|------|
| risk_score | float | 细粒度风险置信度 (0-1) |
| risk_tag | str | 风险类别标签 (29 类) |
| explanation | str | 归因分析文本（enable_reasoning=False 时为空字符串） |
| time | float | 风险标注耗时（秒） |

### 风险类别（29 类）

| 标签 | 类别 | 标签 | 类别 |
|------|------|------|------|
| sec | 安全内容 | ha | 黑客攻击 |
| pc | 色情内容 | ps | 物理安全 |
| dc | 毒品犯罪 | ter | 恐怖主义 |
| dw | 危险武器 | sd | 社会动荡 |
| pi | 盗版侵权 | ext | 极端主义 |
| ec | 经济犯罪 | fin | 金融建议 |
| ac | 辱骂内容 | med | 医疗建议 |
| def | 诽谤内容 | law | 法律建议 |
| ti | 威胁恐吓 | cm | 儿童保护 |
| cy | 网络欺凌 | ma | 未成年虐待 |
| ph | 身体伤害 | md | 未成年犯罪 |
| mh | 心理健康 | | |
| se | 社会伦理 | | |
| sci | 科研伦理 | | |
| pp | 隐私保护 | | |
| cs | 商业机密 | | |
| acc | 账号盗用 | | |
| mc | 恶意代码 | | |

## 动态策略支持

**支持动态策略。** 通过 `policy` 参数传入自定义风险类别定义：

```python
result = guardrail.infer(
    messages=[{"role": "user", "content": "The leaked IMF minutes..."}],
    policy="- a: Unauthorized Access to Closed Institutional Proceedings\n"
           "  - This category covers any attempt of gaining access to "
           "private discussions of international organizations.",
    enable_reasoning=True,
)
# risk_tag 可能返回自定义标签 "a"
```

## 性能优化

- **Fast path (enable_reasoning=False)**：单次 forward pass，无 generate 开销
- **Attention 自适应**：自动选择 flash_attention_2 > sdpa > eager
- **向量化分类**：预计算 token ID tensor，批量提取 logits
- **CUDA warmup**：首次加载自动预热 CUDA kernels
