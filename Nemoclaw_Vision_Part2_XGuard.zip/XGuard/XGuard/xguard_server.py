#!/usr/bin/env python3
"""XGuard Safety Guardrail - FastAPI HTTP Service.

Wraps XGuard's Guardrail class as an HTTP API for preprocessing safety checks.
Usage: python xguard_server.py [--port 8080] [--model-path ./models/XGuard-8B]
"""
import sys
import os
import argparse
import time

# Add XGuard source to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from fastapi import FastAPI
from pydantic import BaseModel, Field
import uvicorn

from inference import Guardrail, RISK_CATEGORIES, RISK_DIMENSIONS

app = FastAPI(title="XGuard Safety Guardrail API", version="1.0")

guardrail: Guardrail | None = None
load_time: float = 0


class GuardRequest(BaseModel):
    messages: list[dict] = Field(..., description="OpenAI-style messages list")
    policy: str | None = Field(None, description="Optional dynamic policy")
    enable_reasoning: bool = Field(False, description="Enable explanation generation")


class GuardResponse(BaseModel):
    safe: bool
    risk_tag: str
    risk_label: str
    risk_dimension: str
    risk_score: float
    explanation: str
    inference_time: float


@app.get("/health")
def health():
    return {
        "status": "ok" if guardrail else "loading",
        "model_load_time": load_time,
    }


@app.post("/guard", response_model=GuardResponse)
def guard(req: GuardRequest):
    result = guardrail.infer(
        messages=req.messages,
        policy=req.policy,
        enable_reasoning=req.enable_reasoning,
    )
    tag = result["risk_tag"]
    return GuardResponse(
        safe=(tag == "sec"),
        risk_tag=tag,
        risk_label=RISK_CATEGORIES.get(tag, tag),
        risk_dimension=RISK_DIMENSIONS.get(tag, "N/A"),
        risk_score=result["risk_score"],
        explanation=result.get("explanation", ""),
        inference_time=result["time"],
    )


def main():
    global guardrail, load_time

    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--model-path", default="./models/XGuard-8B")
    parser.add_argument("--host", default="0.0.0.0")
    args = parser.parse_args()

    print(f"Loading XGuard model from: {args.model_path}")
    t0 = time.time()
    guardrail = Guardrail(args.model_path)
    load_time = round(time.time() - t0, 2)
    print(f"Model loaded in {load_time}s")

    print(f"Starting server on {args.host}:{args.port}")
    uvicorn.run(app, host=args.host, port=args.port, log_level="info")


if __name__ == "__main__":
    main()
