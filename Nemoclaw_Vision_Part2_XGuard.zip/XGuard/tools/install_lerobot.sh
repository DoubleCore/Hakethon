#!/bin/bash
# Install lerobot in conda base env with Chinese mirror
set -e

echo "=== [1/4] Activating conda base env ==="
# Source conda
if [ -f "$HOME/miniconda3/etc/profile.d/conda.sh" ]; then
    source "$HOME/miniconda3/etc/profile.d/conda.sh"
elif [ -f "$HOME/anaconda3/etc/profile.d/conda.sh" ]; then
    source "$HOME/anaconda3/etc/profile.d/conda.sh"
elif [ -f "/opt/conda/etc/profile.d/conda.sh" ]; then
    source "/opt/conda/etc/profile.d/conda.sh"
else
    echo "WARNING: conda.sh not found, trying PATH fallback"
    export PATH="$HOME/miniconda3/bin:$HOME/anaconda3/bin:/opt/conda/bin:$PATH"
fi
conda activate base
echo "Python: $(which python)"
echo "Python version: $(python --version)"
echo "Pip: $(which pip)"

echo ""
echo "=== [2/4] Configuring pip mirror (Tsinghua) ==="
pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple/
pip config set global.trusted-host pypi.tuna.tsinghua.edu.cn
echo "Mirror configured."

echo ""
echo "=== [3/4] Installing lerobot ==="
pip install lerobot -i https://pypi.tuna.tsinghua.edu.cn/simple/ --trusted-host pypi.tuna.tsinghua.edu.cn

echo ""
echo "=== [4/4] Verifying installation ==="
python -c "import lerobot; print('lerobot version:', lerobot.__version__)" 2>/dev/null || \
python -c "import lerobot; print('lerobot imported successfully')"
echo ""
echo "=== Done ==="
