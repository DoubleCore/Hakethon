#!/usr/bin/env python3
"""Install PyTorch with CUDA 13.0 support in vllm312c conda environment."""
import ssh_cmd
cmd = "/home/xsuper/miniconda3/bin/conda run -n vllm312c pip install --upgrade torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu130"
print(ssh_cmd.run(cmd, timeout=300))
