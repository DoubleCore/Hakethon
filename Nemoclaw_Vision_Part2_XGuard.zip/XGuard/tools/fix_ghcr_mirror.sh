#!/bin/bash
# Configure ghcr.io mirror for Docker/containerd and restart

# Step 1: Configure containerd registry mirror for ghcr.io
echo "$SUDO_PASS" | sudo -S mkdir -p /etc/containerd/certs.d/ghcr.io
echo "$SUDO_PASS" | sudo -S tee /etc/containerd/certs.d/ghcr.io/hosts.toml > /dev/null << 'EOF'
server = "https://ghcr.io"

[host."https://ghcr.nju.edu.cn"]
  capabilities = ["pull", "resolve"]
EOF
echo "[1] containerd mirror configured"

# Step 2: Also configure Docker daemon to use containerd certs.d
echo "$SUDO_PASS" | sudo -S python3 -c "
import json
with open('/etc/docker/daemon.json') as f:
    cfg = json.load(f)
# Don't overwrite if not needed
if 'features' not in cfg:
    cfg['features'] = {}
cfg['features']['containerd-snapshotter'] = True
with open('/etc/docker/daemon.json', 'w') as f:
    json.dump(cfg, f, indent=2)
print('[2] Docker daemon.json updated')
" 2>&1 || echo "[2] SKIP: python method failed, trying manual"

# Step 3: Verify the config
echo "[3] Current daemon.json:"
cat /etc/docker/daemon.json
echo ""
echo "[3] Registry mirror config:"
cat /etc/containerd/certs.d/ghcr.io/hosts.toml

# Step 4: Restart Docker
echo "[4] Restarting Docker..."
echo "$SUDO_PASS" | sudo -S systemctl restart docker
echo "$SUDO_PASS" | sudo -S systemctl status docker --no-pager | head -5
echo "[4] Docker restarted"

# Step 5: Test the mirror
echo "[5] Testing ghcr.io pull speed..."
time docker pull ghcr.io/nvidia/openshell/cluster:0.0.22 2>&1

echo "[DONE]"
