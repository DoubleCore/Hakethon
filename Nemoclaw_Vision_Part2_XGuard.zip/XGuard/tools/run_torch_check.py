#!/usr/bin/env python3
"""Check PyTorch version in vllm312c conda environment on remote host."""
import ssh_cmd
cmd = "/home/xsuper/miniconda3/bin/conda run -n vllm312c python -c \"import torch; print('torch:', torch.__version__); print('cuda:', torch.version.cuda); print('available:', torch.cuda.is_available())\""
print(ssh_cmd.run(cmd, timeout=60))
