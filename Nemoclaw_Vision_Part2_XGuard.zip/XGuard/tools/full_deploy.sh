#!/bin/bash
# Pull from NJU mirror and retag for ghcr.io
pkill -f "docker pull" 2>/dev/null
sleep 2

echo "[1] Pulling from NJU mirror (cluster + gateway)..."
docker pull ghcr.nju.edu.cn/nvidia/openshell/cluster:0.0.22
docker pull ghcr.nju.edu.cn/nvidia/openshell/gateway:0.0.22 2>/dev/null || echo "[1] gateway pull failed (will retry)"
if [ $? -ne 0 ]; then
    echo "[1] FAILED"
    exit 1
fi
echo "[1] Pull OK"

echo "[2] Retagging..."
docker tag ghcr.nju.edu.cn/nvidia/openshell/cluster:0.0.22 ghcr.io/nvidia/openshell/cluster:0.0.22
echo "[2] Retag OK"

echo "[3] Verifying..."
docker images | grep openshell
echo "[3] Done"

echo "[4] Also pulling pause image for k3s..."
docker pull dockerproxy.net/rancher/mirrored-pause:3.6 2>/dev/null || docker pull rancher/mirrored-pause:3.6 2>/dev/null || echo "[4] pause already exists"
docker images | grep pause

echo "[5] Starting gateway..."
openshell gateway start --port 8081 -v 2>&1 &
GW_PID=$!
echo "[5] Gateway PID=$GW_PID"

# Wait for container
for i in $(seq 1 120); do
    sleep 2
    CNAME=$(docker ps --format '{{.Names}}' 2>/dev/null | grep openshell-cluster)
    if [ -n "$CNAME" ]; then
        echo "[6] Container found after $((i*2))s: $CNAME"
        CSTATUS=$(docker ps --format '{{.Status}}' --filter "name=$CNAME")
        echo "[6] Status: $CSTATUS"

        # Configure k3s registries FIRST (before k3s tries to pull)
        echo "[7] Configuring k3s registry mirrors..."
        docker exec $CNAME sh -c 'mkdir -p /etc/rancher/k3s && cat > /etc/rancher/k3s/registries.yaml << EOFR
mirrors:
  docker.io:
    endpoint:
      - "https://dockerproxy.net"
      - "https://docker.m.daocloud.io"
      - "https://docker.1ms.run"
  ghcr.io:
    endpoint:
      - "https://ghcr.nju.edu.cn"
EOFR' 2>&1
        echo "[7] Registry config written"

        # Wait for k3s containerd socket to be ready (retry up to 15 times)
        echo "[8] Waiting for k3s containerd socket..."
        SOCK_READY=0
        for attempt in $(seq 1 15); do
            sleep 3
            SOCK=$(docker exec $CNAME sh -c 'test -S /run/k3s/containerd/containerd.sock && echo yes' 2>/dev/null)
            if [ "$SOCK" = "yes" ]; then
                echo "[8] containerd socket ready (attempt $attempt)"
                SOCK_READY=1
                break
            fi
            echo "[8] waiting for containerd socket... ($attempt/15)"
        done

        if [ $SOCK_READY -eq 1 ]; then
            # Import all required k3s system images via ctr pull from mirrors
            # (docker save | ctr import has content digest corruption issues)
            echo "[8] Pulling k3s system images from mirrors..."
            CTR="ctr --address /run/k3s/containerd/containerd.sock --namespace k8s.io"

            # docker.io images -> pull from dockerproxy.net, retag to docker.io
            for IMG in \
                "rancher/mirrored-pause:3.6" \
                "rancher/local-path-provisioner:v0.0.35" \
                "rancher/mirrored-coredns-coredns:1.14.2" \
                "rancher/klipper-helm:v0.9.14-build20260309" \
                "rancher/mirrored-library-busybox:1.37.0" \
                "rancher/mirrored-metrics-server:v0.8.1"
            do
                echo "[8]   pulling dockerproxy.net/$IMG ..."
                docker exec $CNAME $CTR images pull "dockerproxy.net/$IMG" 2>&1 | tail -1
                docker exec $CNAME $CTR images tag "dockerproxy.net/$IMG" "docker.io/$IMG" 2>&1
            done

            # ghcr.io images -> pull from ghcr.nju.edu.cn, retag to ghcr.io
            for IMG in \
                "nvidia/openshell/gateway:0.0.22"
            do
                echo "[8]   pulling ghcr.nju.edu.cn/$IMG ..."
                docker exec $CNAME $CTR images pull "ghcr.nju.edu.cn/$IMG" 2>&1 | tail -1
                docker exec $CNAME $CTR images tag "ghcr.nju.edu.cn/$IMG" "ghcr.io/$IMG" 2>&1
            done

            # registry.k8s.io images -> no mirror, fallback to docker save | ctr import
            for IMG in \
                "registry.k8s.io/agent-sandbox/agent-sandbox-controller:v0.1.0"
            do
                echo "[8]   importing $IMG (docker save fallback) ..."
                docker save $IMG 2>/dev/null | docker exec -i $CNAME $CTR images import - 2>&1 | tail -2
            done

            echo "[8] All images imported"
        else
            echo "[8] WARNING: containerd socket not ready after 45s, skipping import"
        fi

        # Wait for k3s to be ready
        echo "[9] Waiting for k3s namespace..."
        for j in $(seq 1 60); do
            sleep 5
            NS=$(docker exec $CNAME sh -c 'KUBECONFIG=/etc/rancher/k3s/k3s.yaml kubectl get ns openshell -o name 2>/dev/null')
            if echo "$NS" | grep -q "openshell"; then
                echo "[9] k3s ready after $((j*5))s!"
                docker exec $CNAME sh -c 'KUBECONFIG=/etc/rancher/k3s/k3s.yaml kubectl get pods -A 2>&1'
                echo "[DONE] Gateway is running!"
                exit 0
            fi
            if [ $((j % 6)) -eq 0 ]; then
                echo "[9] ...waiting ($((j*5))s)"
            fi
        done
        echo "[9] k3s still not ready after 300s"
        echo "[9] Container status:"
        docker ps -a --format 'table {{.Names}}\t{{.Status}}' | grep openshell
        echo "[9] Last k3s error:"
        docker exec $CNAME sh -c 'KUBECONFIG=/etc/rancher/k3s/k3s.yaml kubectl get events -A --sort-by=.lastTimestamp 2>&1' | tail -10
        exit 1
    fi
    if ! kill -0 $GW_PID 2>/dev/null; then
        echo "[6] GW process exited at $((i*2))s"
        break
    fi
    if [ $((i % 15)) -eq 0 ]; then
        echo "[6] ...still waiting for container ($((i*2))s)"
    fi
done

echo "[TIMEOUT] Container not created"
exit 1
