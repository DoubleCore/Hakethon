#!/bin/bash
# Install and configure Tailscale on the remote server
set -e

echo "=== [1/4] Checking system ==="
OS=$(. /etc/os-release && echo "$ID")
echo "Detected OS: $OS"
uname -r

echo ""
echo "=== [2/4] Installing Tailscale ==="
if command -v tailscale &>/dev/null; then
    echo "Tailscale already installed: $(tailscale version)"
else
    curl -fsSL https://tailscale.com/install.sh | sh
    echo "Tailscale installed: $(tailscale version)"
fi

echo ""
echo "=== [3/4] Enabling and starting tailscaled ==="
systemctl enable tailscaled 2>/dev/null || true
systemctl start tailscaled 2>/dev/null || true
sleep 2
systemctl status tailscaled --no-pager | head -10

echo ""
echo "=== [4/4] Generating auth link ==="
echo "Run the following command to authenticate this node:"
echo ""
echo "  tailscale up --hostname=nvidia-gpu-server"
echo ""
echo "Or with a pre-auth key:"
echo "  tailscale up --authkey=<YOUR_TSKEY> --hostname=nvidia-gpu-server"
echo ""
tailscale status 2>/dev/null || echo "(not authenticated yet — run tailscale up)"
