#!/usr/bin/env python3
"""Simple SSH command executor using paramiko."""
import os
import sys
import paramiko

HOST = os.environ.get("SSH_HOST", "")
PORT = int(os.environ.get("SSH_PORT", "22"))
USER = os.environ.get("SSH_USER", "")
PASS = os.environ.get("SSH_PASS", "")

def run(cmd: str, timeout: int = 120) -> str:
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, port=PORT, username=USER, password=PASS, timeout=30)
    stdin, stdout, stderr = client.exec_command(cmd, timeout=timeout)
    out = stdout.read().decode(errors="replace")
    err = stderr.read().decode(errors="replace")
    code = stdout.channel.recv_exit_status()
    client.close()
    result = out
    if err:
        result += "\n[STDERR]\n" + err
    if code != 0:
        result += f"\n[EXIT CODE: {code}]"
    return result

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python ssh_cmd.py '<command>'")
        sys.exit(1)
    cmd = " ".join(sys.argv[1:])
    output = run(cmd)
    sys.stdout.buffer.write(output.encode("utf-8", errors="replace"))
    sys.stdout.buffer.write(b"\n")
    sys.stdout.buffer.flush()
