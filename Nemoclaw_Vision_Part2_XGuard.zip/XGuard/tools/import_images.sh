#!/bin/bash
CNAME=openshell-cluster-openshell
SOCK=/run/k3s/containerd/containerd.sock

import_img() {
    local IMG=$1
    echo "=== importing $IMG ==="
    docker save "$IMG" | docker exec -i "$CNAME" ctr --address "$SOCK" --namespace k8s.io images import - 2>&1 | tail -3
}

docker tag dockerproxy.net/rancher/mirrored-metrics-server:v0.8.1 rancher/mirrored-metrics-server:v0.8.1 2>/dev/null
docker tag dockerproxy.net/rancher/mirrored-library-busybox:1.37.0 rancher/mirrored-library-busybox:1.37.0 2>/dev/null

import_img rancher/mirrored-metrics-server:v0.8.1
import_img rancher/mirrored-library-busybox:1.37.0

echo "=== pod status ==="
docker exec "$CNAME" sh -c 'KUBECONFIG=/etc/rancher/k3s/k3s.yaml kubectl get pods -A 2>&1'
echo "=== container health ==="
docker ps --format 'table {{.Names}}\t{{.Status}}' | grep openshell
