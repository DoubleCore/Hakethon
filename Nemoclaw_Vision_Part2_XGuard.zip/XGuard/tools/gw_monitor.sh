#!/bin/bash
openshell gateway start --port 8081 -vvv > /tmp/openshell_gw4.log 2>&1 &
GW_PID=$!
echo "GW_PID=$GW_PID"

for i in $(seq 1 90); do
    sleep 2
    LINE=$(docker ps -a --format '{{.Names}} {{.Status}}' 2>/dev/null | grep openshell)
    if [ -n "$LINE" ]; then
        echo "[$i] CONTAINER: $LINE"
    fi
    if ! kill -0 $GW_PID 2>/dev/null; then
        echo "[$i] GW EXITED"
        break
    fi
    if [ $((i % 10)) -eq 0 ]; then
        echo "[$i] still waiting..."
    fi
done

echo "=== GW LOG TAIL ==="
grep -E 'INFO|WARN|ERROR|Downloading|Creating|Starting|Pulling|pull|image' /tmp/openshell_gw4.log | tail -30
echo "=== DONE ==="
