#!/bin/bash
CNAME=openshell-cluster-openshell

echo "=== registries.yaml ==="
docker exec "$CNAME" cat /etc/rancher/k3s/registries.yaml 2>&1

echo "=== k3s process ==="
docker exec "$CNAME" ps aux 2>&1 | grep k3s | grep -v grep | head -5

echo "=== containerd images (docker.io/rancher) ==="
docker exec "$CNAME" ctr --address /run/k3s/containerd/containerd.sock --namespace k8s.io images list 2>&1 | grep rancher

echo "=== pod status ==="
docker exec "$CNAME" sh -c 'KUBECONFIG=/etc/rancher/k3s/k3s.yaml kubectl get pods -A 2>&1'
