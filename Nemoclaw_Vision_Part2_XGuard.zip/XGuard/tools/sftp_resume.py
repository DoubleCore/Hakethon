#!/usr/bin/env python3
"""SFTP resume upload with auto-retry on connection drop."""
import paramiko
import time
import os

SSH_HOST = os.environ.get("SSH_HOST", "")
SSH_PORT = int(os.environ.get("SSH_PORT", "22"))
SSH_USER = os.environ.get("SSH_USER", "")
SSH_PASS = os.environ.get("SSH_PASS", "")

LOCAL_FILE = os.environ.get("SFTP_LOCAL_FILE", "")
REMOTE_FILE = os.environ.get("SFTP_REMOTE_FILE", "")
CHUNK = 131072  # 128KB
MAX_RETRIES = 20
RETRY_DELAY = 10  # seconds


def transfer_chunk(local_size):
    """One transfer session. Returns True if complete, False if interrupted."""
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(SSH_HOST, port=SSH_PORT, username=SSH_USER, password=SSH_PASS, timeout=30)
    transport = client.get_transport()
    transport.set_keepalive(15)
    sftp = client.open_sftp()

    remote_size = sftp.stat(REMOTE_FILE).st_size
    remaining = local_size - remote_size

    if remaining <= 0:
        print(f"  File complete! {remote_size:,} bytes", flush=True)
        sftp.close()
        client.close()
        return True

    pct = remote_size / local_size * 100
    print(f"  Resuming from {remote_size/1e9:.2f} GB ({pct:.1f}%), {remaining/1e9:.2f} GB left", flush=True)

    rf = sftp.file(REMOTE_FILE, "ab")
    rf.set_pipelined(True)

    lf = open(LOCAL_FILE, "rb")
    lf.seek(remote_size)

    transferred = 0
    start_time = time.time()
    last_report = start_time

    try:
        while True:
            data = lf.read(CHUNK)
            if not data:
                break
            rf.write(data)
            transferred += len(data)

            now = time.time()
            if now - last_report >= 10:
                elapsed = now - start_time
                speed = transferred / elapsed if elapsed > 0 else 0
                total_done = remote_size + transferred
                pct = total_done / local_size * 100
                left = local_size - total_done
                eta = left / speed if speed > 0 else 0
                print(
                    f"  {pct:.1f}% | {total_done/1e9:.2f}/{local_size/1e9:.2f} GB | "
                    f"{speed/1e6:.1f} MB/s | ETA {int(eta//60)}m{int(eta%60)}s",
                    flush=True,
                )
                last_report = now
    except Exception as e:
        print(f"  Connection lost after +{transferred/1e6:.1f} MB: {e}", flush=True)
        return False
    finally:
        try:
            rf.close()
        except Exception:
            pass
        lf.close()

    # Verify
    try:
        final_size = sftp.stat(REMOTE_FILE).st_size
        sftp.close()
        client.close()
        return final_size >= local_size
    except Exception:
        return False


def main():
    local_size = os.path.getsize(LOCAL_FILE)
    print(f"=== SFTP Resume Upload (auto-retry) ===", flush=True)
    print(f"  Local: {LOCAL_FILE} ({local_size/1e9:.2f} GB)", flush=True)
    print(f"  Remote: {REMOTE_FILE}", flush=True)
    print(f"  Max retries: {MAX_RETRIES}\n", flush=True)

    for attempt in range(1, MAX_RETRIES + 1):
        print(f"--- Attempt {attempt}/{MAX_RETRIES} ---", flush=True)
        try:
            done = transfer_chunk(local_size)
            if done:
                print(f"\n=== UPLOAD COMPLETE ===", flush=True)
                # Final verify
                client = paramiko.SSHClient()
                client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                client.connect(SSH_HOST, port=SSH_PORT, username=SSH_USER, password=SSH_PASS, timeout=30)
                sftp = client.open_sftp()
                final = sftp.stat(REMOTE_FILE).st_size
                print(f"  Remote: {final:,} bytes", flush=True)
                print(f"  Local:  {local_size:,} bytes", flush=True)
                print(f"  Match:  {'YES' if final == local_size else 'NO'}", flush=True)
                sftp.close()
                client.close()
                return
        except Exception as e:
            print(f"  Connection failed: {e}", flush=True)

        print(f"  Retrying in {RETRY_DELAY}s...\n", flush=True)
        time.sleep(RETRY_DELAY)

    print(f"\n=== FAILED after {MAX_RETRIES} attempts ===", flush=True)


if __name__ == "__main__":
    main()
