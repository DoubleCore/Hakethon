#!/usr/bin/env python3
"""Upload a file via SFTP and execute it on remote server."""
import os
import sys
import paramiko

HOST = os.environ.get("SSH_HOST", "")
PORT = int(os.environ.get("SSH_PORT", "22"))
USER = os.environ.get("SSH_USER", "")
PASS = os.environ.get("SSH_PASS", "")

def main():
    local_file = sys.argv[1] if len(sys.argv) > 1 else "gw_monitor.sh"
    remote_path = f"/tmp/{local_file.split('/')[-1].split(chr(92))[-1]}"

    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(HOST, port=PORT, username=USER, password=PASS, timeout=30)

    # Upload
    sftp = c.open_sftp()
    sftp.put(local_file, remote_path)
    sftp.chmod(remote_path, 0o755)
    sftp.close()
    print(f"Uploaded {local_file} -> {remote_path}")

    # Execute
    stdin, stdout, stderr = c.exec_command(f"bash {remote_path}", timeout=300)
    out = stdout.read().decode(errors="replace")
    err = stderr.read().decode(errors="replace")
    print(out.encode('ascii', errors='replace').decode('ascii'))
    if err:
        print("[STDERR]", err[:500].encode('ascii', errors='replace').decode('ascii'))
    c.close()

if __name__ == "__main__":
    main()
