# NemoClaw Safety Guardrail System

NemoClaw 是一套部署在 NVIDIA DGX Spark 上的 AI 内容安全预处理链，实现"先审后答"的安全架构。

## 架构

```
用户（飞书）
    │
    ▼
┌─────────────────┐
│  飞书 Bridge     │  端口 9000
│  feishu_bridge.py│  接收飞书消息，异步处理
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Safety Gateway  │  端口 8888
│  safety_gateway.py│  OpenAI 兼容 API
└────┬───────┬────┘
     │       │
     ▼       │
┌─────────┐  │  Step 1: 安全审查（~1s）
│ XGuard  │  │  Qwen3-8B 微调模型
│ 8B      │  │  29 类风险分类
│ :8086   │  │  9 类高危拦截
└─────────┘  │
             │  如果安全 ↓
             ▼
      ┌─────────────┐  Step 2: 生成回复（~3-12s）
      │ Gemma-4     │  26B-A4B Q4_K_M 量化
      │ llama.cpp   │  llama-server 推理
      │ :8087       │  67 tokens/s
      └─────────────┘
```

## 核心组件

| 组件 | 文件 | 说明 |
|------|------|------|
| XGuard 安全护栏 | `xguard_server.py` | 基于 Qwen3-8B 微调，29 类风险分类，9 类高危拦截 |
| Safety Gateway | `safety_gateway.py` | 统一入口，串联安全检查与 LLM 推理，OpenAI 兼容 API |
| 飞书 Bridge | `feishu_bridge.py` | 飞书机器人消息桥接，支持单聊和群聊（@机器人） |
| Gemma Server | `gemma_server.py` | Gemma-4 transformers 推理服务（备选方案） |
| Nemotron Server | `nemotron_server.py` | Nemotron-3-Nano-30B 推理服务（备选方案） |

## 工具脚本

| 文件 | 说明 |
|------|------|
| `ssh_cmd.py` | SSH 远程命令执行 |
| `ssh_upload_run.py` | SFTP 上传并执行脚本 |
| `sftp_resume.py` | 断点续传 SFTP 上传 |
| `tunnel_proxy.py` | SSH 反向隧道代理 |
| `full_deploy.sh` | 完整部署脚本 |
| `check_k3s.sh` | K3s 集群诊断 |
| `fix_ghcr_mirror.sh` | GHCR 镜像源配置 |
| `import_images.sh` | 容器镜像导入 K3s |
| `gw_monitor.sh` | 网关监控 |
| `install_lerobot.sh` | LeRobot 安装 |
| `install_tailscale.sh` | Tailscale 安装 |
| `install_torch_cu130.py` | PyTorch CUDA 13.0 安装 |
| `run_torch_check.py` | PyTorch 环境验证 |
| `range_server.py` | 分片文件服务 |

## 硬件环境

| 项目 | 规格 |
|------|------|
| 设备 | NVIDIA DGX Spark |
| GPU | NVIDIA GB10 (Blackwell 架构) |
| 统一内存 | ~119 GB |
| CPU | ARM aarch64 (Grace) |

## 安全设计

1. **先审后答** — 所有用户消息必须先经过 XGuard 安全检查
2. **分层拦截** — 仅拦截 9 类高危内容（pc, dc, dw, ter, mc, ha, cm, ma, ext），其余放行
3. **快速拦截** — 危险内容 ~1s 内拦截，不消耗 LLM 资源
4. **异步处理** — 飞书 Bridge 立即返回 200，后台异步处理

## 环境变量

运行前需设置以下环境变量：

```bash
# 飞书应用凭据
export FEISHU_APP_ID="your_app_id"
export FEISHU_APP_SECRET="your_app_secret"
export FEISHU_VERIFICATION_TOKEN="your_token"
export FEISHU_ENCRYPT_KEY="your_encrypt_key"

# SSH 连接（工具脚本使用）
export SSH_HOST="your_server_ip"
export SSH_PORT="your_ssh_port"
export SSH_USER="your_username"
export SSH_PASS="your_password"
```

## 启动顺序

```bash
# 1. XGuard 安全模型
python xguard_server.py --port 8086 --model-path /path/to/XGuard-8B

# 2. Gemma 主模型（llama.cpp）
llama-server \
  -m /path/to/gemma-4-26B-A4B-it-Q4_K_M.gguf \
  --port 8087 --host 0.0.0.0 -ngl 99 -c 4096 --reasoning off

# 3. Safety Gateway
python safety_gateway.py --port 8888 --xguard-url http://127.0.0.1:8086 --llm-url http://127.0.0.1:8087

# 4. 飞书 Bridge
python feishu_bridge.py --port 9000 --gateway-url http://127.0.0.1:8888
```

## License

MIT
